package com.wardencity;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.Map;

public final class WardenCityPlugin extends JavaPlugin {
    private DataStore data;
    private LootManager loot;
    private ChestManager chests;
    private WardenManager wardens;
    private MerchantManager merchant;
    private DungeonService dungeon;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        if (!new File(getDataFolder(), "loot.yml").exists()) saveResource("loot.yml", false);

        data = new DataStore(this);
        loot = new LootManager(this);
        chests = new ChestManager(this);
        wardens = new WardenManager(this);
        merchant = new MerchantManager(this);
        dungeon = new DungeonService(this);

        data.load();
        loot.reload();
        chests.reloadConfig();
        chests.loadFrom(data.loadedYaml());
        ensureWorld();

        Bukkit.getPluginManager().registerEvents(chests, this);
        Bukkit.getPluginManager().registerEvents(wardens, this);
        Bukkit.getPluginManager().registerEvents(merchant, this);
        Bukkit.getPluginManager().registerEvents(new ProtectionListener(this), this);

        WardenCityCommand cmd = new WardenCityCommand(this);
        PluginCommand pc = getCommand("wardencity");
        if (pc != null) {
            pc.setExecutor(cmd);
            pc.setTabCompleter(cmd);
        }

        chests.startTasks();
        wardens.startTasks();
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (data.isDirty()) data.save(false);
        }, 600L, 600L);
        getLogger().info("WardenCity запущен. Данж " + (data.dungeon == null ? "не создан (/wardencity create)" : "загружен"));
    }

    @Override
    public void onDisable() {
        if (data != null) data.save(true);
    }

    public void reloadAll() {
        reloadConfig();
        loot.reload();
        chests.reloadConfig();
        chests.startTasks();
        wardens.startTasks();
    }

    public World ensureWorld() {
        FileConfiguration c = getConfig();
        String name = c.getString("world.name", "warden_city");
        World w = Bukkit.getWorld(name);
        if (w == null && c.getBoolean("world.create-if-missing", true)) {
            try {
                WorldCreator wc = new WorldCreator(name);
                wc.environment(World.Environment.NORMAL);
                wc.generator(new VoidGenerator());
                wc.biomeProvider(new DeepDarkBiomes());
                wc.generateStructures(false);
                w = wc.createWorld();
            } catch (Throwable t) {
                getLogger().severe("Не удалось создать мир " + name + ": " + t);
            }
        }
        if (w != null) {
            try {
                w.setSpawnFlags(false, false);
                w.setStorm(false);
            } catch (Throwable t) {
                getLogger().warning("Настройка мира: " + t.getMessage());
            }
        }
        return w;
    }

    public Location exitLocation() {
        FileConfiguration c = getConfig();
        World ew = Bukkit.getWorld(c.getString("exit.world", "world"));
        if (ew == null) ew = Bukkit.getWorlds().get(0);
        if (c.getBoolean("exit.use-world-spawn", true)) return ew.getSpawnLocation();
        return new Location(ew, c.getDouble("exit.x", 0.5), c.getDouble("exit.y", 100), c.getDouble("exit.z", 0.5));
    }

    public void send(CommandSender to, String msg) {
        to.sendMessage(Text.c(getConfig().getString("messages.prefix", "&8[&3Город Вардена&8] &7") + msg));
    }

    /** Монеты, опыт и команды из результата лута (предметы выдаёт вызывающий код). */
    public void grantNonItems(Player p, LootManager.Result r) {
        if (r.coins > 0) {
            data.addCoins(p.getUniqueId(), r.coins);
            send(p, "&6+" + r.coins + " монет");
        }
        if (r.exp > 0) p.giveExp(r.exp);
        for (String cmd : r.commands)
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("%player%", p.getName()));
    }

    public DataStore data() { return data; }
    public LootManager loot() { return loot; }
    public ChestManager chests() { return chests; }
    public WardenManager wardens() { return wardens; }
    public MerchantManager merchant() { return merchant; }
    public DungeonService dungeon() { return dungeon; }
}
