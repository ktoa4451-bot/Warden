package com.wardencity;

import org.bukkit.World;

import java.util.ArrayList;
import java.util.List;

/** Информация о созданном данже (хранится в data.yml). */
public final class Dungeon {
    public String world;
    public int ox, oy, oz, sx, sy, sz;
    public long seed;
    public double spawnX, spawnY, spawnZ;
    public final List<double[]> merchants = new ArrayList<>();
    public final List<Zone> zones = new ArrayList<>();

    public static final class Zone {
        public final double x, y, z;
        public final String kind;
        public long lastSpawn; // только в памяти

        public Zone(double x, double y, double z, String kind) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.kind = kind;
        }
    }

    public boolean contains(World w, double x, double y, double z) {
        if (w == null || !w.getName().equals(world)) return false;
        return x >= ox && x < ox + sx && y >= oy && y < oy + sy && z >= oz && z < oz + sz;
    }

    public boolean containsBlock(World w, int x, int y, int z) {
        return contains(w, x, y, z);
    }
}
