package com.wardencity;

import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Защита данжа от разрушения. */
public final class ProtectionListener implements Listener {
    private final WardenCityPlugin plugin;

    public ProtectionListener(WardenCityPlugin plugin) {
        this.plugin = plugin;
    }

    private boolean enabled() {
        return plugin.getConfig().getBoolean("protection.enabled", true);
    }

    private boolean inside(Block b) {
        Dungeon d = plugin.data().dungeon;
        return d != null && d.contains(b.getWorld(), b.getX(), b.getY(), b.getZ());
    }

    private boolean bypass(Player p) {
        return p.hasPermission("wardencity.admin") && p.getGameMode() == GameMode.CREATIVE;
    }

    private Set<Material> allowed() {
        Set<Material> s = new HashSet<>();
        for (String n : plugin.getConfig().getStringList("protection.break-allowed")) {
            Material m = Material.matchMaterial(n.toUpperCase(Locale.ROOT));
            if (m != null) s.add(m);
        }
        return s;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (!enabled() || !inside(e.getBlock()) || bypass(e.getPlayer())) return;
        if (allowed().contains(e.getBlock().getType())) {
            e.setDropItems(false);
            return;
        }
        e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (!enabled() || !inside(e.getBlock()) || bypass(e.getPlayer())) return;
        e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucket(PlayerBucketEmptyEvent e) {
        if (!enabled() || !inside(e.getBlock()) || bypass(e.getPlayer())) return;
        e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent e) {
        if (!enabled() || !inside(e.getBlock()) || bypass(e.getPlayer())) return;
        e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onExplode(EntityExplodeEvent e) {
        if (!enabled()) return;
        e.blockList().removeIf(this::inside);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) {
        if (!enabled()) return;
        e.blockList().removeIf(this::inside);
    }
}
