package com.wardencity;

import org.bukkit.Bukkit;
import org.bukkit.block.data.BlockData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Постройка данжа целиком в памяти (индексы палитры), потом вставляется в мир порциями. */
public final class CityPlan {
    public final int sx, sy, sz;
    private final short[] data;
    private final List<BlockData> palette = new ArrayList<>();
    private final Map<String, Short> index = new HashMap<>();

    public final List<ChestSpot> chests = new ArrayList<>();
    public final List<ZoneSpot> zones = new ArrayList<>();
    public final List<int[]> merchants = new ArrayList<>();
    public int spawnX, spawnY, spawnZ;

    public static final class ChestSpot {
        public final int x, y, z;
        public final String tier;

        public ChestSpot(int x, int y, int z, String tier) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.tier = tier;
        }
    }

    public static final class ZoneSpot {
        public final int x, y, z;
        public final String kind;

        public ZoneSpot(int x, int y, int z, String kind) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.kind = kind;
        }
    }

    public CityPlan(int sx, int sy, int sz) {
        this.sx = sx;
        this.sy = sy;
        this.sz = sz;
        this.data = new short[sx * sz * sy];
        reg("minecraft:air"); // индекс 0
    }

    /** Только из основного потока! */
    public short reg(String blockData) {
        Short v = index.get(blockData);
        if (v != null) return v;
        BlockData bd = Bukkit.createBlockData(blockData);
        short id = (short) palette.size();
        palette.add(bd);
        index.put(blockData, id);
        return id;
    }

    public BlockData blockData(short id) {
        return palette.get(id);
    }

    public boolean in(int x, int y, int z) {
        return x >= 0 && y >= 0 && z >= 0 && x < sx && y < sy && z < sz;
    }

    public short get(int x, int y, int z) {
        if (!in(x, y, z)) return 0;
        return data[(x * sz + z) * sy + y];
    }

    public void set(int x, int y, int z, short id) {
        if (!in(x, y, z)) return;
        data[(x * sz + z) * sy + y] = id;
    }
}
