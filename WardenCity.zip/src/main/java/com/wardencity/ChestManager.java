package com.wardencity;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Сундуки данжа. Настоящий блок-сундук лишь «маркер»: содержимое лежит в виртуальном инвентаре,
 * который открывает только один игрок за раз. Вставлять предметы в него нельзя (защита от дюпов).
 */
public final class ChestManager implements Listener {
    private static final int SIZE = 27;

    public static final class State {
        final int x, y, z;
        String tier;
        long readyAt;
        ItemStack[] contents;
        Inventory open;

        State(int x, int y, int z, String tier) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.tier = tier;
        }
    }

    public static final class Holder implements InventoryHolder {
        final State state;
        Inventory inv;

        Holder(State s) {
            this.state = s;
        }

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    private static final class Tier {
        String id, display, table;
        long cooldownMs;
        Color color = Color.WHITE;
    }

    private final WardenCityPlugin plugin;
    private final Map<Long, State> chests = new HashMap<>();
    private final Map<String, Tier> tiers = new LinkedHashMap<>();
    private final Map<UUID, Long> lastClick = new HashMap<>();
    private final Random rnd = new Random();
    private BukkitTask particleTask;

    public ChestManager(WardenCityPlugin plugin) {
        this.plugin = plugin;
    }

    static long key(int x, int y, int z) {
        return ((long) (x & 0x3FFFFFF) << 38) | ((long) (z & 0x3FFFFFF) << 12) | ((y + 2048) & 0xFFF);
    }

    public void reloadConfig() {
        tiers.clear();
        ConfigurationSection ts = plugin.getConfig().getConfigurationSection("chests.tiers");
        if (ts == null) return;
        for (String id : ts.getKeys(false)) {
            ConfigurationSection s = ts.getConfigurationSection(id);
            if (s == null) continue;
            Tier t = new Tier();
            t.id = id;
            t.display = s.getString("display", id);
            t.table = s.getString("loot-table", id);
            t.cooldownMs = Math.max(1L, s.getLong("cooldown-minutes", 30)) * 60_000L;
            try {
                t.color = Color.fromRGB(Integer.parseInt(s.getString("color", "#FFFFFF").replace("#", ""), 16));
            } catch (NumberFormatException ex) {
                plugin.getLogger().warning("Неверный цвет у сундука " + id);
            }
            tiers.put(id, t);
        }
    }

    private Tier tier(String id) {
        Tier t = tiers.get(id);
        if (t != null) return t;
        return tiers.values().isEmpty() ? new Tier() : tiers.values().iterator().next();
    }

    // ------------------------------------------------------------ реестр

    public void clearAll() {
        chests.clear();
    }

    public void register(int x, int y, int z, String tier) {
        chests.put(key(x, y, z), new State(x, y, z, tier));
    }

    public int count() {
        return chests.size();
    }

    public int readyCount() {
        long now = System.currentTimeMillis();
        int n = 0;
        for (State s : chests.values()) if (now >= s.readyAt) n++;
        return n;
    }

    public Map<String, Integer> countByTier() {
        Map<String, Integer> m = new LinkedHashMap<>();
        for (State s : chests.values()) m.merge(s.tier, 1, Integer::sum);
        return m;
    }

    public void resetTimers() {
        for (State s : chests.values()) {
            s.readyAt = 0;
            s.contents = null;
        }
        plugin.data().markDirty();
    }

    public void loadFrom(YamlConfiguration y) {
        chests.clear();
        ConfigurationSection cs = y.getConfigurationSection("chests");
        if (cs == null) return;
        for (String k : cs.getKeys(false)) {
            ConfigurationSection s = cs.getConfigurationSection(k);
            if (s == null) continue;
            State st = new State(s.getInt("x"), s.getInt("y"), s.getInt("z"), s.getString("tier", "common"));
            st.readyAt = s.getLong("ready-at");
            ConfigurationSection items = s.getConfigurationSection("items");
            if (items != null) {
                ItemStack[] arr = new ItemStack[SIZE];
                boolean any = false;
                for (String slot : items.getKeys(false)) {
                    try {
                        int i = Integer.parseInt(slot);
                        ItemStack it = items.getItemStack(slot);
                        if (i >= 0 && i < SIZE && it != null) {
                            arr[i] = it;
                            any = true;
                        }
                    } catch (NumberFormatException ignored) {
                    }
                }
                if (any) st.contents = arr;
            }
            chests.put(key(st.x, st.y, st.z), st);
        }
        plugin.getLogger().info("Загружено сундуков: " + chests.size());
    }

    public void writeTo(YamlConfiguration out) {
        for (State s : chests.values()) {
            String base = "chests." + s.x + "_" + s.y + "_" + s.z;
            out.set(base + ".x", s.x);
            out.set(base + ".y", s.y);
            out.set(base + ".z", s.z);
            out.set(base + ".tier", s.tier);
            out.set(base + ".ready-at", s.readyAt);
            ItemStack[] c = s.open != null ? s.open.getContents() : s.contents;
            if (c != null)
                for (int i = 0; i < c.length && i < SIZE; i++)
                    if (c[i] != null && !c[i].getType().isAir()) out.set(base + ".items." + i, c[i]);
        }
    }

    // ------------------------------------------------------------ задачи

    public void startTasks() {
        if (particleTask != null) particleTask.cancel();
        particleTask = Bukkit.getScheduler().runTaskTimer(plugin, this::particles, 40L, 30L);
    }

    private void particles() {
        Dungeon d = plugin.data().dungeon;
        if (d == null) return;
        World w = Bukkit.getWorld(d.world);
        if (w == null) return;
        List<Player> ps = w.getPlayers();
        if (ps.isEmpty()) return;
        long now = System.currentTimeMillis();
        for (State s : chests.values()) {
            if (now < s.readyAt) continue;
            Location loc = new Location(w, s.x + 0.5, s.y + 1.1, s.z + 0.5);
            boolean near = false;
            for (Player p : ps)
                if (p.getLocation().distanceSquared(loc) < 400) {
                    near = true;
                    break;
                }
            if (!near) continue;
            w.spawnParticle(Particle.DUST, loc, 3, 0.25, 0.15, 0.25, 0,
                    new Particle.DustOptions(tier(s.tier).color, 1.2f));
        }
    }

    // ------------------------------------------------------------ открытие

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Block bl = e.getClickedBlock();
        if (bl == null || bl.getType() != Material.CHEST) return;
        State s = chests.get(key(bl.getX(), bl.getY(), bl.getZ()));
        Dungeon d = plugin.data().dungeon;
        if (s == null || d == null || !bl.getWorld().getName().equals(d.world)) return;
        e.setCancelled(true);
        if (e.getHand() != EquipmentSlot.HAND) return;
        Player p = e.getPlayer();
        long now = System.currentTimeMillis();
        long delay = plugin.getConfig().getLong("chests.click-delay-ms", 400);
        Long last = lastClick.get(p.getUniqueId());
        if (last != null && now - last < delay) return;
        lastClick.put(p.getUniqueId(), now);
        open(p, s);
    }

    private void open(Player p, State s) {
        Tier t = tier(s.tier);
        long now = System.currentTimeMillis();
        if (s.open != null && !s.open.getViewers().isEmpty()) {
            plugin.send(p, "&cСундук сейчас открыт другим игроком.");
            return;
        }
        boolean fresh = false;
        LootManager.Result res = null;
        if (now >= s.readyAt) {
            res = plugin.loot().roll(t.table, rnd);
            s.contents = layout(res.items);
            int jit = Math.max(0, plugin.getConfig().getInt("chests.jitter-percent", 10));
            long cd = t.cooldownMs + (long) (t.cooldownMs * (rnd.nextInt(2 * jit + 1) - jit) / 100.0);
            s.readyAt = now + Math.max(1000L, cd);
            fresh = true;
        } else if (isEmpty(s.contents)) {
            long left = (s.readyAt - now) / 1000L;
            plugin.send(p, "&7Сундук пуст. Обновится через &e" + fmt(left) + "&7.");
            p.playSound(p.getLocation(), Sound.BLOCK_CHEST_CLOSE, 0.6f, 0.6f);
            return;
        }
        Holder h = new Holder(s);
        Inventory inv = Bukkit.createInventory(h, SIZE, Text.c(t.display));
        h.inv = inv;
        if (s.contents != null) inv.setContents(s.contents);
        s.open = inv;
        p.openInventory(inv);
        if (fresh && res != null) {
            plugin.grantNonItems(p, res);
            plugin.data().saveSoon();
        }
        Sound snd = "legendary".equals(s.tier) ? Sound.UI_TOAST_CHALLENGE_COMPLETE : Sound.BLOCK_CHEST_OPEN;
        p.playSound(p.getLocation(), snd, 0.8f, 0.8f);
        if (fresh) p.sendActionBar(Text.c(t.display + " &7открыт"));
        plugin.data().markDirty();
    }

    private ItemStack[] layout(List<ItemStack> items) {
        ItemStack[] arr = new ItemStack[SIZE];
        List<Integer> slots = new ArrayList<>();
        for (int i = 0; i < SIZE; i++) slots.add(i);
        Collections.shuffle(slots, rnd);
        for (int i = 0; i < items.size() && i < SIZE; i++) arr[slots.get(i)] = items.get(i);
        if (items.size() > SIZE) plugin.getLogger().warning("В сундуке выпало больше " + SIZE + " предметов, лишние отброшены.");
        return arr;
    }

    private static boolean isEmpty(ItemStack[] c) {
        if (c == null) return true;
        for (ItemStack i : c) if (i != null && !i.getType().isAir()) return false;
        return true;
    }

    private static String fmt(long sec) {
        if (sec < 0) sec = 0;
        long h = sec / 3600, m = (sec % 3600) / 60, s = sec % 60;
        if (h > 0) return h + "ч " + m + "м";
        if (m > 0) return m + "м " + s + "с";
        return s + "с";
    }

    // ------------------------------------------------------------ защита от дюпов

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof Holder)) return;
        InventoryAction a = e.getAction();
        boolean inTop = e.getClickedInventory() != null && e.getClickedInventory() == top;
        if (a == InventoryAction.COLLECT_TO_CURSOR || a == InventoryAction.CLONE_STACK || a == InventoryAction.UNKNOWN) {
            e.setCancelled(true);
            return;
        }
        if (inTop) {
            switch (a) {
                case PICKUP_ALL, PICKUP_HALF, PICKUP_ONE, PICKUP_SOME, MOVE_TO_OTHER_INVENTORY,
                     DROP_ALL_SLOT, DROP_ONE_SLOT, NOTHING -> {
                }
                case HOTBAR_SWAP, HOTBAR_MOVE_AND_READD -> {
                    ItemStack other;
                    if (e.getClick() == ClickType.SWAP_OFFHAND)
                        other = e.getWhoClicked().getInventory().getItemInOffHand();
                    else if (e.getHotbarButton() >= 0)
                        other = e.getWhoClicked().getInventory().getItem(e.getHotbarButton());
                    else other = null;
                    if (other != null && !other.getType().isAir()) e.setCancelled(true);
                }
                default -> e.setCancelled(true);
            }
        } else if (a == InventoryAction.MOVE_TO_OTHER_INVENTORY) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrag(InventoryDragEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof Holder)) return;
        int size = top.getSize();
        for (int raw : e.getRawSlots())
            if (raw < size) {
                e.setCancelled(true);
                return;
            }
    }

    @EventHandler
    public void onClose(org.bukkit.event.inventory.InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder() instanceof Holder h)) return;
        State s = h.state;
        ItemStack[] c = e.getInventory().getContents();
        s.contents = isEmpty(c) ? null : c;
        s.open = null;
        Player p = e.getPlayer() instanceof Player pl ? pl : null;
        if (p != null) p.playSound(p.getLocation(), Sound.BLOCK_CHEST_CLOSE, 0.8f, 0.8f);
        plugin.data().saveSoon();
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        lastClick.remove(e.getPlayer().getUniqueId());
        if (e.getPlayer().getOpenInventory().getTopInventory().getHolder() instanceof Holder)
            e.getPlayer().closeInventory();
    }
}
