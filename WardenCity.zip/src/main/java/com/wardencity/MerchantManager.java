package com.wardencity;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

/** Торговец: скупает ценные предметы за монеты. */
public final class MerchantManager implements Listener {
    private final WardenCityPlugin plugin;
    private final NamespacedKey key;

    public MerchantManager(WardenCityPlugin plugin) {
        this.plugin = plugin;
        this.key = new NamespacedKey(plugin, "wc_merchant");
    }

    public void removeAll(World w, Dungeon d) {
        for (Villager v : new ArrayList<>(w.getEntitiesByClass(Villager.class)))
            if (v.getPersistentDataContainer().has(key, PersistentDataType.BYTE)) v.remove();
    }

    public void spawnAll(World w, Dungeon d) {
        removeAll(w, d);
        String name = plugin.getConfig().getString("merchant.name", "&6Торговец");
        for (double[] m : d.merchants) {
            Location loc = new Location(w, m[0], m[1], m[2], 0f, 0f);
            w.spawn(loc, Villager.class, v -> {
                v.customName(Text.c(name));
                v.setCustomNameVisible(true);
                v.setAI(false);
                v.setInvulnerable(true);
                v.setSilent(true);
                v.setPersistent(true);
                v.setRemoveWhenFarAway(false);
                v.setCollidable(false);
                v.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);
            });
        }
    }

    private long priceOf(ItemStack it) {
        ItemMeta meta = it.getItemMeta();
        if (meta != null) {
            Integer p = meta.getPersistentDataContainer().get(plugin.loot().sellKey, PersistentDataType.INTEGER);
            if (p != null) return p;
        }
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("merchant.prices");
        if (s == null) return 0;
        return s.getLong(it.getType().name(), 0);
    }

    @EventHandler
    public void onInteract(PlayerInteractEntityEvent e) {
        if (!(e.getRightClicked() instanceof Villager v)) return;
        if (!v.getPersistentDataContainer().has(key, PersistentDataType.BYTE)) return;
        e.setCancelled(true);
        if (e.getHand() != EquipmentSlot.HAND) return;
        sell(e.getPlayer());
    }

    private void sell(Player p) {
        ItemStack[] c = p.getInventory().getStorageContents();
        long total = 0;
        int count = 0;
        for (int i = 0; i < c.length; i++) {
            ItemStack it = c[i];
            if (it == null || it.getType() == Material.AIR) continue;
            long price = priceOf(it);
            if (price <= 0) continue;
            total += price * it.getAmount();
            count += it.getAmount();
            c[i] = null;
        }
        if (total <= 0) {
            plugin.send(p, "&7У вас нет ничего, что меня интересует. Ищите ресурсы в Городе Вардена!");
            return;
        }
        p.getInventory().setStorageContents(c);
        plugin.data().addCoins(p.getUniqueId(), total);
        plugin.send(p, "&aПродано предметов: &e" + count + "&a. Получено монет: &6" + total
                + "&a. Баланс: &6" + plugin.data().coins(p.getUniqueId()));
        plugin.data().saveSoon();
    }
}
