package com.wardencity;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Warden;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/** Варден: зоны появления, контроль количества, награда за победу (один раз на игрока по кулдауну). */
public final class WardenManager implements Listener {
    private final WardenCityPlugin plugin;
    private final NamespacedKey tag;
    private final Map<UUID, Map<UUID, Double>> damage = new HashMap<>();
    private final Set<UUID> processed = new HashSet<>();
    private final Random rnd = new Random();
    private BukkitTask task;

    public WardenManager(WardenCityPlugin plugin) {
        this.plugin = plugin;
        this.tag = new NamespacedKey(plugin, "wc_warden");
    }

    public void startTasks() {
        if (task != null) task.cancel();
        long interval = Math.max(5L, plugin.getConfig().getLong("warden.spawn.check-interval-ticks", 20));
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::check, 60L, interval);
    }

    private World world() {
        Dungeon d = plugin.data().dungeon;
        return d == null ? null : Bukkit.getWorld(d.world);
    }

    public int aliveCount() {
        World w = world();
        return w == null ? 0 : w.getEntitiesByClass(Warden.class).size();
    }

    private void check() {
        FileConfiguration c = plugin.getConfig();
        Dungeon d = plugin.data().dungeon;
        if (d == null || !c.getBoolean("warden.spawn.enabled", true)) return;
        World w = Bukkit.getWorld(d.world);
        if (w == null) return;
        List<Player> ps = w.getPlayers();
        if (ps.isEmpty()) return;
        Collection<Warden> alive = w.getEntitiesByClass(Warden.class);
        if (alive.size() >= c.getInt("warden.max-alive", 3)) return;
        long now = System.currentTimeMillis();
        long cd = c.getLong("warden.spawn.zone-cooldown-minutes", 15) * 60_000L;
        double radius = c.getDouble("warden.spawn.trigger-radius", 14);
        double chance = c.getDouble("warden.spawn.chance", 0.08);
        double sprint = c.getDouble("warden.spawn.sprint-multiplier", 2.0);
        for (Dungeon.Zone z : d.zones) {
            if (now - z.lastSpawn < cd) continue;
            Location zl = new Location(w, z.x, z.y, z.z);
            boolean wardenNear = false;
            for (Warden wd : alive)
                if (wd.getLocation().distanceSquared(zl) < 48 * 48) {
                    wardenNear = true;
                    break;
                }
            if (wardenNear) continue;
            for (Player p : ps) {
                if (p.getGameMode() != GameMode.SURVIVAL && p.getGameMode() != GameMode.ADVENTURE) continue;
                if (p.isSneaking()) continue; // крадущийся игрок почти не шумит
                if (p.getLocation().distanceSquared(zl) > radius * radius) continue;
                double ch = chance * (p.isSprinting() ? sprint : 1.0);
                if (rnd.nextDouble() >= ch) continue;
                spawn(zl, p);
                z.lastSpawn = now;
                return; // не более одного за проверку
            }
        }
    }

    public Warden spawn(Location loc, Player target) {
        World w = loc.getWorld();
        if (w == null) return null;
        Warden wd = w.spawn(loc, Warden.class, x -> x.getPersistentDataContainer().set(tag, PersistentDataType.BYTE, (byte) 1));
        if (target != null) {
            try {
                wd.setAnger(target, plugin.getConfig().getInt("warden.spawn.initial-anger", 80));
            } catch (Throwable t) {
                plugin.getLogger().warning("Не удалось задать гнев Вардену: " + t.getMessage());
            }
        }
        w.playSound(loc, Sound.ENTITY_WARDEN_EMERGE, 3f, 1f);
        for (Player p : w.getPlayers())
            if (p.getLocation().distanceSquared(loc) < 40 * 40)
                p.sendActionBar(Text.c("&4Варден пробудился..."));
        return wd;
    }

    private void setup(Warden w) {
        if (!w.isValid()) return;
        double h = plugin.getConfig().getDouble("warden.health", 500);
        AttributeInstance ai = w.getAttribute(Attribute.MAX_HEALTH);
        if (ai != null && h > 0) {
            ai.setBaseValue(h);
            w.setHealth(Math.min(h, ai.getValue()));
        }
        w.getPersistentDataContainer().set(tag, PersistentDataType.BYTE, (byte) 1);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent e) {
        Dungeon d = plugin.data().dungeon;
        if (d == null) return;
        LivingEntity ent = e.getEntity();
        if (!d.world.equals(ent.getWorld().getName())) return;
        CreatureSpawnEvent.SpawnReason r = e.getSpawnReason();
        if (ent instanceof Warden w) {
            if (r != CreatureSpawnEvent.SpawnReason.CUSTOM) {
                FileConfiguration c = plugin.getConfig();
                if (!c.getBoolean("warden.shrieker-spawn", true) || aliveCount() >= c.getInt("warden.max-alive", 3)) {
                    e.setCancelled(true);
                    return;
                }
            }
            Bukkit.getScheduler().runTask(plugin, () -> setup(w));
            return;
        }
        if (r != CreatureSpawnEvent.SpawnReason.CUSTOM && r != CreatureSpawnEvent.SpawnReason.COMMAND
                && r != CreatureSpawnEvent.SpawnReason.SPAWNER_EGG) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Warden w)) return;
        Entity dmg = e.getDamager();
        Player p = null;
        if (dmg instanceof Player pl) p = pl;
        else if (dmg instanceof Projectile pr) {
            ProjectileSource src = pr.getShooter();
            if (src instanceof Player pl2) p = pl2;
        }
        if (p == null) return;
        damage.computeIfAbsent(w.getUniqueId(), k -> new HashMap<>()).merge(p.getUniqueId(), e.getFinalDamage(), Double::sum);
    }

    @EventHandler
    public void onDeath(EntityDeathEvent e) {
        if (!(e.getEntity() instanceof Warden w)) return;
        Dungeon d = plugin.data().dungeon;
        if (d == null || !d.world.equals(w.getWorld().getName())) return;
        if (!processed.add(w.getUniqueId())) return; // защита от повторной выдачи награды
        if (processed.size() > 5000) processed.clear();
        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("warden.reward.keep-vanilla-drops", false)) e.getDrops().clear();
        e.setDroppedExp(c.getInt("warden.reward.exp", 500));
        Map<UUID, Double> dm = damage.remove(w.getUniqueId());
        if (dm == null || dm.isEmpty()) return;
        AttributeInstance ai = w.getAttribute(Attribute.MAX_HEALTH);
        double max = ai != null ? ai.getValue() : 500;
        double need = max * c.getDouble("warden.reward.min-damage-percent", 5) / 100.0;
        long now = System.currentTimeMillis();
        long cdMs = c.getLong("warden.reward.player-cooldown-minutes", 30) * 60_000L;
        String table = c.getString("warden.reward.loot-table", "warden");
        List<String> names = new ArrayList<>();
        for (Map.Entry<UUID, Double> en : dm.entrySet()) {
            Player p = Bukkit.getPlayer(en.getKey());
            if (p == null || !p.isOnline() || en.getValue() < need) continue;
            if (!d.contains(p.getWorld(), p.getLocation().getX(), p.getLocation().getY(), p.getLocation().getZ())) continue;
            long ready = plugin.data().bossReadyAt(p.getUniqueId());
            if (now < ready) {
                plugin.send(p, "&cНаграду за Вардена вы уже получали. Следующая через &e" + ((ready - now) / 60000L + 1) + " мин.");
                continue;
            }
            plugin.data().setBossReady(p.getUniqueId(), now + cdMs);
            LootManager.Result res = plugin.loot().roll(table, rnd);
            for (ItemStack it : res.items) {
                Map<Integer, ItemStack> left = p.getInventory().addItem(it);
                for (ItemStack rest : left.values()) p.getWorld().dropItemNaturally(p.getLocation(), rest);
            }
            plugin.grantNonItems(p, res);
            plugin.send(p, "&aВы победили Вардена! Награда получена.");
            names.add(p.getName());
        }
        if (!names.isEmpty() && c.getBoolean("warden.reward.broadcast", true))
            Bukkit.broadcast(Text.c("&8[&3Город Вардена&8] &7Варден повержен! Победители: &e" + String.join("&7, &e", names)));
        plugin.data().saveSoon();
    }
}
