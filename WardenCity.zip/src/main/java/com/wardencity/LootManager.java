package com.wardencity;

import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

/** Таблицы лута из loot.yml. */
public final class LootManager {
    private final WardenCityPlugin plugin;
    private final Map<String, Table> tables = new HashMap<>();
    public final NamespacedKey sellKey;

    public static final class Result {
        public final List<ItemStack> items = new ArrayList<>();
        public final List<String> commands = new ArrayList<>();
        public long coins;
        public int exp;
    }

    private static final class Entry {
        String type = "item";
        Material mat;
        int[] amount = {1, 1};
        double weight = 1;
        String name;
        List<String> lore = new ArrayList<>();
        Map<String, Integer> ench = new HashMap<>();
        Integer cmd;
        int sell;
        String command;
    }

    private static final class Table {
        int minR = 1, maxR = 1;
        final List<Entry> entries = new ArrayList<>();
        double total;
    }

    public LootManager(WardenCityPlugin plugin) {
        this.plugin = plugin;
        this.sellKey = new NamespacedKey(plugin, "wc_sell");
    }

    public void reload() {
        tables.clear();
        File f = new File(plugin.getDataFolder(), "loot.yml");
        if (!f.exists()) plugin.saveResource("loot.yml", false);
        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
        ConfigurationSection ts = y.getConfigurationSection("tables");
        if (ts == null) {
            plugin.getLogger().warning("loot.yml: нет секции tables");
            return;
        }
        for (String id : ts.getKeys(false)) {
            ConfigurationSection s = ts.getConfigurationSection(id);
            if (s == null) continue;
            Table t = new Table();
            int[] rr = range(s.get("rolls"), 1);
            t.minR = rr[0];
            t.maxR = rr[1];
            for (Map<?, ?> m : s.getMapList("entries")) {
                Entry e = parse(id, m);
                if (e != null && e.weight > 0) {
                    t.entries.add(e);
                    t.total += e.weight;
                }
            }
            tables.put(id, t);
        }
        plugin.getLogger().info("Загружено таблиц лута: " + tables.size());
    }

    static int[] range(Object o, int def) {
        if (o instanceof Number n) return new int[]{n.intValue(), n.intValue()};
        if (o instanceof ConfigurationSection cs) {
            int lo = cs.getInt("min", def);
            return new int[]{lo, Math.max(lo, cs.getInt("max", lo))};
        }
        if (o instanceof Map<?, ?> m) {
            Object a = m.get("min"), b = m.get("max");
            int lo = a instanceof Number na ? na.intValue() : def;
            int hi = b instanceof Number nb ? nb.intValue() : lo;
            return new int[]{lo, Math.max(lo, hi)};
        }
        if (o instanceof String str) {
            String s = str.trim();
            try {
                int k = s.indexOf('-', 1);
                if (k > 0) {
                    int lo = Integer.parseInt(s.substring(0, k).trim());
                    int hi = Integer.parseInt(s.substring(k + 1).trim());
                    return new int[]{lo, Math.max(lo, hi)};
                }
                int v = Integer.parseInt(s);
                return new int[]{v, v};
            } catch (NumberFormatException ignored) {
            }
        }
        return new int[]{def, def};
    }

    private static String str(Object o, String def) {
        return o == null ? def : String.valueOf(o);
    }

    private Entry parse(String table, Map<?, ?> m) {
        Entry e = new Entry();
        e.type = str(m.get("type"), "item").toLowerCase(Locale.ROOT);
        Object w = m.get("weight");
        e.weight = w instanceof Number n ? n.doubleValue() : 1.0;
        e.amount = range(m.get("amount"), 1);
        switch (e.type) {
            case "coins", "exp" -> {
            }
            case "command" -> {
                e.command = str(m.get("command"), null);
                if (e.command == null) return null;
            }
            case "item" -> {
                e.mat = Material.matchMaterial(str(m.get("material"), ""));
                if (e.mat == null) {
                    plugin.getLogger().warning("loot.yml [" + table + "]: неизвестный материал " + m.get("material"));
                    return null;
                }
                e.name = m.get("name") == null ? null : str(m.get("name"), null);
                if (m.get("lore") instanceof List<?> l) for (Object o : l) e.lore.add(String.valueOf(o));
                if (m.get("enchants") instanceof Map<?, ?> em)
                    for (Map.Entry<?, ?> en : em.entrySet())
                        if (en.getValue() instanceof Number lv) e.ench.put(String.valueOf(en.getKey()), lv.intValue());
                if (m.get("custom-model-data") instanceof Number c) e.cmd = c.intValue();
                if (m.get("sell-price") instanceof Number sp) e.sell = sp.intValue();
            }
            default -> {
                plugin.getLogger().warning("loot.yml [" + table + "]: неизвестный type " + e.type);
                return null;
            }
        }
        return e;
    }

    public Result roll(String tableId, Random rnd) {
        Result res = new Result();
        Table t = tables.get(tableId);
        if (t == null || t.entries.isEmpty()) {
            plugin.getLogger().warning("Таблица лута не найдена или пуста: " + tableId);
            return res;
        }
        int rolls = t.minR + (t.maxR > t.minR ? rnd.nextInt(t.maxR - t.minR + 1) : 0);
        for (int i = 0; i < rolls; i++) {
            double x = rnd.nextDouble() * t.total;
            Entry pick = t.entries.get(t.entries.size() - 1);
            for (Entry e : t.entries) {
                x -= e.weight;
                if (x < 0) {
                    pick = e;
                    break;
                }
            }
            apply(pick, res, rnd);
        }
        return res;
    }

    private void apply(Entry e, Result res, Random rnd) {
        int amt = e.amount[0] + (e.amount[1] > e.amount[0] ? rnd.nextInt(e.amount[1] - e.amount[0] + 1) : 0);
        switch (e.type) {
            case "coins" -> res.coins += amt;
            case "exp" -> res.exp += amt;
            case "command" -> res.commands.add(e.command);
            default -> res.items.add(build(e, amt));
        }
    }

    private ItemStack build(Entry e, int amt) {
        ItemStack it = new ItemStack(e.mat, Math.max(1, Math.min(amt, e.mat.getMaxStackSize())));
        ItemMeta meta = it.getItemMeta();
        if (meta == null) return it;
        if (e.name != null) meta.displayName(Text.item(e.name));
        if (!e.lore.isEmpty()) {
            List<Component> l = new ArrayList<>();
            for (String s : e.lore) l.add(Text.item(s));
            meta.lore(l);
        }
        for (Map.Entry<String, Integer> en : e.ench.entrySet()) {
            Enchantment ench = Registry.ENCHANTMENT.get(NamespacedKey.minecraft(en.getKey().toLowerCase(Locale.ROOT)));
            if (ench == null) {
                plugin.getLogger().warning("loot.yml: неизвестное зачарование " + en.getKey());
                continue;
            }
            if (meta instanceof EnchantmentStorageMeta esm) esm.addStoredEnchant(ench, en.getValue(), true);
            else meta.addEnchant(ench, en.getValue(), true);
        }
        if (e.cmd != null) meta.setCustomModelData(e.cmd);
        if (e.sell > 0) meta.getPersistentDataContainer().set(sellKey, PersistentDataType.INTEGER, e.sell);
        it.setItemMeta(meta);
        return it;
    }
}
