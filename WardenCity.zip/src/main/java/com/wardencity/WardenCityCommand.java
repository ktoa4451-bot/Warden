package com.wardencity;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class WardenCityCommand implements CommandExecutor, TabCompleter {
    private final WardenCityPlugin plugin;

    public WardenCityCommand(WardenCityPlugin plugin) {
        this.plugin = plugin;
    }

    private boolean admin(CommandSender s) {
        if (s.hasPermission("wardencity.admin")) return true;
        plugin.send(s, "&cНет прав.");
        return false;
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (a.length == 0) {
            help(s);
            return true;
        }
        String sub = a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "create" -> {
                if (!admin(s)) return true;
                Long seed = null;
                if (a.length > 1) {
                    try {
                        seed = Long.parseLong(a[1]);
                    } catch (NumberFormatException ex) {
                        plugin.send(s, "&cСид должен быть числом.");
                        return true;
                    }
                }
                plugin.dungeon().create(s, seed);
            }
            case "delete" -> {
                if (!admin(s)) return true;
                if (a.length < 2 || !a[1].equalsIgnoreCase("confirm")) {
                    plugin.send(s, "&eЭто удалит весь данж. Подтвердите: &f/wardencity delete confirm");
                    return true;
                }
                plugin.dungeon().delete(s);
            }
            case "reset" -> {
                if (!admin(s)) return true;
                if (a.length < 2 || !a[1].equalsIgnoreCase("confirm")) {
                    plugin.send(s, "&eДанж будет перестроен (тот же сид), сундуки сброшены. Подтвердите: &f/wardencity reset confirm");
                    return true;
                }
                plugin.dungeon().reset(s);
            }
            case "reload" -> {
                if (!admin(s)) return true;
                plugin.reloadAll();
                plugin.send(s, "&aНастройки и таблицы лута перезагружены.");
            }
            case "teleport", "tp" -> {
                if (!admin(s)) return true;
                Player target;
                if (a.length > 1) target = Bukkit.getPlayerExact(a[1]);
                else target = s instanceof Player p ? p : null;
                if (target == null) {
                    plugin.send(s, "&cУкажите игрока: /wardencity teleport <ник>");
                    return true;
                }
                if (!teleportIn(target)) plugin.send(s, "&cДанж не создан или мир не загружен.");
            }
            case "enter" -> {
                if (!(s instanceof Player p)) {
                    plugin.send(s, "&cТолько для игроков.");
                    return true;
                }
                if (!p.hasPermission("wardencity.enter")) {
                    plugin.send(s, "&cНет прав.");
                    return true;
                }
                if (!teleportIn(p)) plugin.send(s, "&cДанж ещё не создан.");
            }
            case "leave" -> {
                if (!(s instanceof Player p)) {
                    plugin.send(s, "&cТолько для игроков.");
                    return true;
                }
                Dungeon d = plugin.data().dungeon;
                if (d == null || !p.getWorld().getName().equals(d.world)) {
                    plugin.send(s, "&7Вы не в Городе Вардена.");
                    return true;
                }
                p.teleport(plugin.exitLocation());
                plugin.send(s, "&7Вы покинули Город Вардена.");
            }
            case "balance", "bal" -> {
                if (!(s instanceof Player p)) {
                    plugin.send(s, "&cТолько для игроков.");
                    return true;
                }
                plugin.send(s, "&7Ваши монеты: &6" + plugin.data().coins(p.getUniqueId()));
            }
            case "warden" -> {
                if (!admin(s)) return true;
                if (!(s instanceof Player p)) {
                    plugin.send(s, "&cТолько для игроков.");
                    return true;
                }
                plugin.wardens().spawn(p.getLocation(), p);
                plugin.send(s, "&7Варден призван.");
            }
            case "info" -> {
                if (!admin(s)) return true;
                info(s);
            }
            default -> help(s);
        }
        return true;
    }

    private boolean teleportIn(Player p) {
        Dungeon d = plugin.data().dungeon;
        if (d == null) return false;
        World w = Bukkit.getWorld(d.world);
        if (w == null) return false;
        p.teleport(new Location(w, d.spawnX, d.spawnY, d.spawnZ, 180f, 0f));
        plugin.send(p, "&7Добро пожаловать в &3Город Вардена&7. Тише, пожалуйста...");
        return true;
    }

    private void info(CommandSender s) {
        Dungeon d = plugin.data().dungeon;
        plugin.send(s, "&bСтатус: " + (plugin.dungeon().isBusy() ? "&eидёт операция" : "&aсвободно"));
        if (d == null) {
            plugin.send(s, "&7Данж не создан (&e/wardencity create&7).");
            return;
        }
        plugin.send(s, "&7Мир: &f" + d.world + " &7| начало: &f" + d.ox + " " + d.oy + " " + d.oz
                + " &7| размер: &f" + d.sx + "x" + d.sz + "x" + d.sy + " &7| сид: &f" + d.seed);
        StringBuilder tiers = new StringBuilder();
        for (Map.Entry<String, Integer> e : plugin.chests().countByTier().entrySet())
            tiers.append(e.getKey()).append(": ").append(e.getValue()).append("  ");
        plugin.send(s, "&7Сундуков: &f" + plugin.chests().count() + " &7(готовы: &a" + plugin.chests().readyCount()
                + "&7) &8" + tiers);
        plugin.send(s, "&7Зон Вардена: &f" + d.zones.size() + " &7| Вардены живы: &c" + plugin.wardens().aliveCount()
                + " &7| торговцев: &f" + d.merchants.size());
        plugin.send(s, "&7Спавн: &f" + (int) d.spawnX + " " + (int) d.spawnY + " " + (int) d.spawnZ);
    }

    private void help(CommandSender s) {
        plugin.send(s, "&b/wardencity &7- команды:");
        plugin.send(s, "&f enter &7/ &fleave &7/ &fbalance &7- для игроков");
        if (s.hasPermission("wardencity.admin"))
            plugin.send(s, "&f create [сид] | delete confirm | reset confirm | teleport [ник] | reload | info | warden");
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String alias, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            List<String> all = new ArrayList<>(List.of("enter", "leave", "balance"));
            if (s.hasPermission("wardencity.admin"))
                all.addAll(List.of("create", "delete", "teleport", "reload", "reset", "info", "warden"));
            for (String x : all) if (x.startsWith(a[0].toLowerCase(Locale.ROOT))) out.add(x);
        } else if (a.length == 2 && s.hasPermission("wardencity.admin")) {
            String sub = a[0].toLowerCase(Locale.ROOT);
            if (sub.equals("delete") || sub.equals("reset")) out.add("confirm");
            if (sub.equals("teleport") || sub.equals("tp"))
                for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
        }
        return out;
    }
}
