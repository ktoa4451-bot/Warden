package com.wardencity;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

/** Сохранение данных (data.yml): данж, сундуки, монеты, кулдауны наград. */
public final class DataStore {
    private final WardenCityPlugin plugin;
    private final File file;
    private YamlConfiguration loaded = new YamlConfiguration();
    public Dungeon dungeon;
    private final Map<UUID, Long> coins = new HashMap<>();
    private final Map<UUID, Long> bossReady = new HashMap<>();
    private boolean dirty;
    private boolean scheduled;
    private final Object lock = new Object();

    public DataStore(WardenCityPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "data.yml");
    }

    public void load() {
        if (file.exists()) loaded = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection ds = loaded.getConfigurationSection("dungeon");
        if (ds != null) {
            Dungeon d = new Dungeon();
            d.world = ds.getString("world", "warden_city");
            d.ox = ds.getInt("ox");
            d.oy = ds.getInt("oy");
            d.oz = ds.getInt("oz");
            d.sx = ds.getInt("sx");
            d.sy = ds.getInt("sy");
            d.sz = ds.getInt("sz");
            d.seed = ds.getLong("seed");
            d.spawnX = ds.getDouble("spawn.x");
            d.spawnY = ds.getDouble("spawn.y");
            d.spawnZ = ds.getDouble("spawn.z");
            for (String s : ds.getStringList("merchants")) {
                String[] a = s.split(";");
                if (a.length == 3) d.merchants.add(new double[]{pd(a[0]), pd(a[1]), pd(a[2])});
            }
            for (String s : ds.getStringList("zones")) {
                String[] a = s.split(";");
                if (a.length == 4) d.zones.add(new Dungeon.Zone(pd(a[0]), pd(a[1]), pd(a[2]), a[3]));
            }
            dungeon = d;
        }
        ConfigurationSection ps = loaded.getConfigurationSection("players");
        if (ps != null)
            for (String k : ps.getKeys(false)) {
                try {
                    UUID id = UUID.fromString(k);
                    coins.put(id, ps.getLong(k + ".coins"));
                    long br = ps.getLong(k + ".boss-ready-at");
                    if (br > 0) bossReady.put(id, br);
                } catch (IllegalArgumentException ignored) {
                }
            }
    }

    private static double pd(String s) {
        try {
            return Double.parseDouble(s);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    public YamlConfiguration loadedYaml() {
        return loaded;
    }

    public long coins(UUID id) {
        return coins.getOrDefault(id, 0L);
    }

    public void addCoins(UUID id, long amount) {
        coins.merge(id, amount, Long::sum);
        dirty = true;
    }

    public long bossReadyAt(UUID id) {
        return bossReady.getOrDefault(id, 0L);
    }

    public void setBossReady(UUID id, long t) {
        bossReady.put(id, t);
        dirty = true;
    }

    public void markDirty() {
        dirty = true;
    }

    public boolean isDirty() {
        return dirty;
    }

    /** Сохранить через ~1 секунду (чтобы не писать файл на каждый клик). */
    public void saveSoon() {
        dirty = true;
        if (scheduled) return;
        scheduled = true;
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            scheduled = false;
            save(false);
        }, 20L);
    }

    public void save(boolean sync) {
        dirty = false;
        String text = build();
        if (sync) write(text);
        else Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> write(text));
    }

    private String build() {
        YamlConfiguration out = new YamlConfiguration();
        Dungeon d = dungeon;
        if (d != null) {
            out.set("dungeon.world", d.world);
            out.set("dungeon.ox", d.ox);
            out.set("dungeon.oy", d.oy);
            out.set("dungeon.oz", d.oz);
            out.set("dungeon.sx", d.sx);
            out.set("dungeon.sy", d.sy);
            out.set("dungeon.sz", d.sz);
            out.set("dungeon.seed", d.seed);
            out.set("dungeon.spawn.x", d.spawnX);
            out.set("dungeon.spawn.y", d.spawnY);
            out.set("dungeon.spawn.z", d.spawnZ);
            java.util.List<String> m = new java.util.ArrayList<>();
            for (double[] a : d.merchants) m.add(a[0] + ";" + a[1] + ";" + a[2]);
            out.set("dungeon.merchants", m);
            java.util.List<String> z = new java.util.ArrayList<>();
            for (Dungeon.Zone a : d.zones) z.add(a.x + ";" + a.y + ";" + a.z + ";" + a.kind);
            out.set("dungeon.zones", z);
        }
        for (Map.Entry<UUID, Long> e : coins.entrySet()) out.set("players." + e.getKey() + ".coins", e.getValue());
        for (Map.Entry<UUID, Long> e : bossReady.entrySet())
            out.set("players." + e.getKey() + ".boss-ready-at", e.getValue());
        plugin.chests().writeTo(out);
        return out.saveToString();
    }

    private void write(String text) {
        synchronized (lock) {
            try {
                Path tmp = file.toPath().resolveSibling("data.yml.tmp");
                Files.createDirectories(tmp.getParent());
                Files.writeString(tmp, text, StandardCharsets.UTF_8);
                try {
                    Files.move(tmp, file.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
                } catch (IOException ex) {
                    Files.move(tmp, file.toPath(), StandardCopyOption.REPLACE_EXISTING);
                }
            } catch (IOException ex) {
                plugin.getLogger().log(Level.SEVERE, "Не удалось сохранить data.yml", ex);
            }
        }
    }
}
