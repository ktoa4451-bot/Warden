package com.wardencity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Процедурная генерация «Города Вардена» в памяти (CityPlan). Работает в асинхронном потоке,
 * поэтому не обращается к Bukkit API.
 *
 * Вертикальная схема (относительно начала данжа):
 *   y 0..11   : нижний уровень - катакомбы (лабиринт, залы, склепы, скалковые тоннели), пол на y=1, ходить по y=2
 *   y 11      : поверхность города, ходить по y=12
 *   y 12..H-5 : огромная пещера с площадью, храмом, зданиями, разломами и мостами
 *   y H-4..H-1: потолок
 */
final class CityGenerator {
    static final int[] DX = {0, 1, 0, -1};
    static final int[] DZ = {-1, 0, 1, 0};
    static final int M = 3, FLOOR = 11, WALK = 12, RIFT_HALF = 5;

    private final CityPlan p;
    private final Blocks b;
    private final Random r;
    private final int sx, sz, H, CEIL;
    private final boolean[][] occ;
    private final int cfgHalls, cfgVaults, cfgBuildings;
    private final double chestDensity, lanternDensity;

    private int cw, ch;
    private boolean[][] eOpen, sOpen, hallCell, vaultCell;
    private int rz, rx;
    private int plazaR;

    CityGenerator(CityPlan p, Blocks b, long seed, int halls, int vaults, int buildings,
                  double chestDensity, double lanternDensity) {
        this.p = p;
        this.b = b;
        this.r = new Random(seed);
        this.sx = p.sx;
        this.sz = p.sz;
        this.H = p.sy;
        this.CEIL = H - 4;
        this.occ = new boolean[sx][sz];
        this.cfgHalls = halls;
        this.cfgVaults = vaults;
        this.cfgBuildings = buildings;
        this.chestDensity = chestDensity;
        this.lanternDensity = lanternDensity;
    }

    void generate() {
        shell();
        maze();
        cityFloor();
        rifts();
        shafts();
        bridges();
        plaza();
        temple();
        colossalColumns();
        buildings();
        streets();
        ceilingDecor();
        finish();
    }

    // ------------------------------------------------------------------ helpers

    private void fill(int x1, int y1, int z1, int x2, int y2, int z2, short id) {
        int ax = Math.max(0, Math.min(x1, x2)), bx = Math.min(sx - 1, Math.max(x1, x2));
        int ay = Math.max(0, Math.min(y1, y2)), by = Math.min(H - 1, Math.max(y1, y2));
        int az = Math.max(0, Math.min(z1, z2)), bz = Math.min(sz - 1, Math.max(z1, z2));
        for (int x = ax; x <= bx; x++)
            for (int z = az; z <= bz; z++)
                for (int y = ay; y <= by; y++)
                    p.set(x, y, z, id);
    }

    private boolean solid(int x, int y, int z) {
        return p.in(x, y, z) && p.get(x, y, z) != 0;
    }

    private boolean air(int x, int y, int z) {
        return p.in(x, y, z) && p.get(x, y, z) == 0;
    }

    private void reserve(int x1, int z1, int x2, int z2) {
        for (int x = Math.max(0, Math.min(x1, x2)); x <= Math.min(sx - 1, Math.max(x1, x2)); x++)
            for (int z = Math.max(0, Math.min(z1, z2)); z <= Math.min(sz - 1, Math.max(z1, z2)); z++)
                occ[x][z] = true;
    }

    private boolean free(int x1, int z1, int x2, int z2) {
        if (x1 < M + 1 || z1 < M + 1 || x2 > sx - M - 2 || z2 > sz - M - 2) return false;
        for (int x = x1; x <= x2; x++)
            for (int z = z1; z <= z2; z++)
                if (occ[x][z]) return false;
        return true;
    }

    private short wallMat() {
        int v = r.nextInt(100);
        if (v < 55) return b.BRICKS;
        if (v < 70) return b.CRACKED_BRICKS;
        if (v < 88) return b.TILES;
        if (v < 95) return b.DEEPSLATE;
        return b.COBBLED;
    }

    private short floorMat() {
        int v = r.nextInt(100);
        if (v < 62) return b.TILES;
        if (v < 78) return b.POLISHED;
        if (v < 93) return b.CRACKED_TILES;
        return b.DEEPSLATE;
    }

    private void shuffle(int[] a) {
        for (int i = a.length - 1; i > 0; i--) {
            int j = r.nextInt(i + 1);
            int t = a[i];
            a[i] = a[j];
            a[j] = t;
        }
    }

    private boolean chest(int x, int y, int z, int dir, String tier, boolean requireBack) {
        if (!air(x, y, z)) return false;
        if (!solid(x, y - 1, z)) return false;
        if (requireBack && !solid(x - DX[dir], y, z - DZ[dir])) return false;
        p.set(x, y, z, b.CHEST[dir]);
        p.chests.add(new CityPlan.ChestSpot(x, y, z, tier));
        return true;
    }

    private void blob(int cx, int cz, int rad, int y, short id, boolean onlySolid) {
        for (int dx = -rad; dx <= rad; dx++)
            for (int dz = -rad; dz <= rad; dz++) {
                if (dx * dx + dz * dz > rad * rad + r.nextInt(3)) continue;
                int x = cx + dx, z = cz + dz;
                if (!p.in(x, y, z)) continue;
                if (onlySolid && !solid(x, y, z)) continue;
                p.set(x, y, z, id);
            }
    }

    // ------------------------------------------------------------------ shell

    private void shell() {
        for (int x = 0; x < sx; x++)
            for (int z = 0; z < sz; z++) {
                boolean border = x < M || x >= sx - M || z < M || z >= sz - M;
                boolean outer = x == 0 || x == sx - 1 || z == 0 || z == sz - 1;
                for (int y = 0; y <= FLOOR; y++) {
                    short id;
                    if (y == 0) id = b.REINFORCED;
                    else {
                        int v = r.nextInt(100);
                        id = v < 7 ? b.COBBLED : (v < 11 ? b.TUFF : b.DEEPSLATE);
                    }
                    p.set(x, y, z, id);
                }
                if (border)
                    for (int y = FLOOR + 1; y < H; y++)
                        p.set(x, y, z, outer ? b.REINFORCED : wallMat());
                for (int y = CEIL; y < H; y++) {
                    short id;
                    if (y == H - 1) id = b.REINFORCED;
                    else if (y == CEIL) {
                        int v = r.nextInt(100);
                        id = v < 50 ? b.DEEPSLATE : (v < 75 ? b.BRICKS : (v < 90 ? b.COBBLED : b.TUFF));
                    } else id = b.DEEPSLATE;
                    p.set(x, y, z, id);
                }
            }
    }

    // ------------------------------------------------------------------ catacombs (maze)

    private int cx0(int i) {
        return M + 4 * i + 1;
    }

    private int cz0(int j) {
        return M + 4 * j + 1;
    }

    private boolean inCell(int i, int j) {
        return i >= 0 && j >= 0 && i < cw && j < ch;
    }

    private boolean isOpen(int i, int j, int d) {
        switch (d) {
            case 0: return j > 0 && sOpen[i][j - 1];
            case 1: return i < cw - 1 && eOpen[i][j];
            case 2: return j < ch - 1 && sOpen[i][j];
            default: return i > 0 && eOpen[i - 1][j];
        }
    }

    private void setOpen(int i, int j, int d) {
        switch (d) {
            case 0: sOpen[i][j - 1] = true; break;
            case 1: eOpen[i][j] = true; break;
            case 2: sOpen[i][j] = true; break;
            default: eOpen[i - 1][j] = true; break;
        }
    }

    /** {x1,z1,x2,z2} прохода/стены между клеткой и соседом. */
    private int[] passageBox(int i, int j, int d) {
        int x = cx0(i), z = cz0(j);
        switch (d) {
            case 0: return new int[]{x, z - 1, x + 2, z - 1};
            case 1: return new int[]{x + 3, z, x + 3, z + 2};
            case 2: return new int[]{x, z + 3, x + 2, z + 3};
            default: return new int[]{x - 1, z, x - 1, z + 2};
        }
    }

    private void maze() {
        cw = (sx - 2 * M - 1) / 4;
        ch = (sz - 2 * M - 1) / 4;
        eOpen = new boolean[cw][ch];
        sOpen = new boolean[cw][ch];
        hallCell = new boolean[cw][ch];
        vaultCell = new boolean[cw][ch];

        boolean[][] seen = new boolean[cw][ch];
        int[] st = new int[cw * ch];
        int sp = 0;
        int si = cw / 2, sj = ch / 2;
        seen[si][sj] = true;
        st[sp++] = si * ch + sj;
        while (sp > 0) {
            int cur = st[sp - 1];
            int i = cur / ch, j = cur % ch;
            int[] order = {0, 1, 2, 3};
            shuffle(order);
            boolean moved = false;
            for (int d : order) {
                int ni = i + DX[d], nj = j + DZ[d];
                if (inCell(ni, nj) && !seen[ni][nj]) {
                    setOpen(i, j, d);
                    seen[ni][nj] = true;
                    st[sp++] = ni * ch + nj;
                    moved = true;
                    break;
                }
            }
            if (!moved) sp--;
        }
        // петли
        for (int i = 0; i < cw; i++)
            for (int j = 0; j < ch; j++)
                if (r.nextInt(100) < 7) {
                    int d = r.nextInt(4);
                    if (inCell(i + DX[d], j + DZ[d]) && !isOpen(i, j, d)) setOpen(i, j, d);
                }
        // вырезаем коридоры
        for (int i = 0; i < cw; i++)
            for (int j = 0; j < ch; j++) {
                int x = cx0(i), z = cz0(j);
                fill(x, 2, z, x + 2, 6, z + 2, b.AIR);
                for (int a = 0; a < 3; a++)
                    for (int c = 0; c < 3; c++) p.set(x + a, 1, z + c, floorMat());
                if (i < cw - 1 && eOpen[i][j]) {
                    fill(x + 3, 2, z, x + 3, 6, z + 2, b.AIR);
                    for (int c = 0; c < 3; c++) p.set(x + 3, 1, z + c, floorMat());
                }
                if (j < ch - 1 && sOpen[i][j]) {
                    fill(x, 2, z + 3, x + 2, 6, z + 3, b.AIR);
                    for (int a = 0; a < 3; a++) p.set(x + a, 1, z + 3, floorMat());
                }
            }

        halls();
        List<int[]> dead = deadEnds();
        Collections.shuffle(dead, r);
        int v = 0;
        int idx = 0;
        for (; idx < dead.size() && v < cfgVaults; idx++, v++) makeVault(dead.get(idx), v);
        for (; idx < dead.size(); idx++) deadEndChest(dead.get(idx));
        decorateCells();
        sculkTunnels();
    }

    private List<int[]> deadEnds() {
        List<int[]> list = new ArrayList<>();
        for (int i = 0; i < cw; i++)
            for (int j = 0; j < ch; j++) {
                if (hallCell[i][j]) continue;
                int deg = 0, dd = -1;
                for (int d = 0; d < 4; d++)
                    if (isOpen(i, j, d)) {
                        deg++;
                        dd = d;
                    }
                if (deg == 1) list.add(new int[]{i, j, dd});
            }
        return list;
    }

    private void halls() {
        int target = cfgHalls > 0 ? cfgHalls : Math.max(3, cw * ch / 260);
        int made = 0, tries = 0;
        while (made < target && tries < 500) {
            tries++;
            int w = 3 + r.nextInt(3), h = 3 + r.nextInt(3);
            int i0 = 1 + r.nextInt(Math.max(1, cw - w - 2));
            int j0 = 1 + r.nextInt(Math.max(1, ch - h - 2));
            if (i0 + w >= cw || j0 + h >= ch) continue;
            boolean ok = true;
            for (int i = i0 - 1; i <= i0 + w && ok; i++)
                for (int j = j0 - 1; j <= j0 + h; j++)
                    if (inCell(i, j) && hallCell[i][j]) {
                        ok = false;
                        break;
                    }
            if (!ok) continue;
            for (int i = i0; i < i0 + w; i++)
                for (int j = j0; j < j0 + h; j++) hallCell[i][j] = true;
            buildHall(i0, j0, w, h);
            made++;
        }
    }

    private void buildHall(int i0, int j0, int w, int h) {
        int x1 = cx0(i0), x2 = cx0(i0 + w - 1) + 2, z1 = cz0(j0), z2 = cz0(j0 + h - 1) + 2;
        fill(x1, 2, z1, x2, 9, z2, b.AIR);
        for (int x = x1; x <= x2; x++)
            for (int z = z1; z <= z2; z++) p.set(x, 1, z, floorMat());
        for (int px = x1 + 2; px <= x2 - 2; px += 4)
            for (int pz = z1 + 2; pz <= z2 - 2; pz += 4) {
                fill(px, 2, pz, px, 9, pz, b.POLISHED);
                p.set(px, 2, pz, b.CHISELED);
                p.set(px, 9, pz, b.CHISELED);
                if (air(px + 2, 9, pz + 2) && solid(px + 2, 10, pz + 2)) p.set(px + 2, 9, pz + 2, b.LANTERN_H);
            }
        int mx = (x1 + x2) / 2, mz = (z1 + z2) / 2;
        for (int x = x1; x <= x2; x++) if (air(x, 2, mz)) p.set(x, 2, mz, b.BLUE_CARPET);
        for (int z = z1; z <= z2; z++) if (air(mx, 2, z)) p.set(mx, 2, z, b.BLUE_CARPET);
        blob(mx, mz, 4, 1, b.SCULK, false);
        p.set(mx, 2, mz, b.CATALYST);
        int[][] sh = {{3, 3}, {-3, 3}, {3, -3}, {-3, -3}};
        for (int[] o : sh) if (air(mx + o[0], 2, mz + o[1])) p.set(mx + o[0], 2, mz + o[1], b.SHRIEKER);
        for (int k = 0; k < 6; k++) {
            int x = x1 + 1 + r.nextInt(x2 - x1 - 1), z = z1 + 1 + r.nextInt(z2 - z1 - 1);
            if (air(x, 2, z) && solid(x, 1, z)) p.set(x, 2, z, b.SENSOR);
        }
        p.zones.add(new CityPlan.ZoneSpot(mx + 2, 2, mz + 2, "hall"));
        int nChests = 2 + r.nextInt(3);
        for (int k = 0; k < nChests; k++) {
            String tier = (k == 0 && r.nextInt(100) < 35) ? "epic" : "rare";
            for (int t = 0; t < 40; t++) {
                int side = r.nextInt(4);
                int x, z, dir;
                if (side == 0) { z = z1; x = x1 + 1 + r.nextInt(x2 - x1 - 1); dir = 2; }
                else if (side == 1) { x = x2; z = z1 + 1 + r.nextInt(z2 - z1 - 1); dir = 3; }
                else if (side == 2) { z = z2; x = x1 + 1 + r.nextInt(x2 - x1 - 1); dir = 0; }
                else { x = x1; z = z1 + 1 + r.nextInt(z2 - z1 - 1); dir = 1; }
                if (chest(x, 2, z, dir, tier, true)) break;
            }
        }
    }

    /** Секретная комната: тупик, вход в который закрыт треснутыми кирпичами. */
    private void makeVault(int[] c, int n) {
        int i = c[0], j = c[1], d = c[2];
        int[] pb = passageBox(i, j, d);
        fill(pb[0], 2, pb[1], pb[2], 6, pb[3], b.CRACKED_BRICKS);
        vaultCell[i][j] = true;
        String tier = n < 3 ? "legendary" : "epic";
        int bd = (d + 2) % 4;
        int mx = cx0(i) + 1, mz = cz0(j) + 1;
        p.set(mx, 1, mz, b.CHISELED);
        chest(mx + DX[bd], 2, mz + DZ[bd], d, tier, false);
        for (int a = -1; a <= 1; a += 2)
            for (int c2 = -1; c2 <= 1; c2 += 2)
                if (air(mx + a, 2, mz + c2)) p.set(mx + a, 2, mz + c2, b.CANDLE);
        p.set(mx, 6, mz, b.LANTERN_H);
        int hx = cx0(i) + (d == 1 ? 4 : (d == 3 ? -2 : 0));
        int hz = cz0(j) + (d == 2 ? 4 : (d == 0 ? -2 : 0));
        if (air(hx, 2, hz)) p.set(hx, 2, hz, b.CANDLE); // подсказка у стенки
    }

    private void deadEndChest(int[] c) {
        if (r.nextDouble() > chestDensity) return;
        int i = c[0], j = c[1], d = c[2];
        double dist = Math.hypot(i - cw / 2.0, j - ch / 2.0) / (cw / 2.0);
        double roll = r.nextDouble() + dist * 0.5;
        String tier = roll < 0.75 ? "common" : (roll < 1.2 ? "rare" : "epic");
        int bd = (d + 2) % 4;
        int mx = cx0(i) + 1, mz = cz0(j) + 1;
        chest(mx + DX[bd], 2, mz + DZ[bd], d, tier, false);
    }

    private void decorateCells() {
        for (int i = 0; i < cw; i++)
            for (int j = 0; j < ch; j++) {
                if (hallCell[i][j] || vaultCell[i][j]) continue;
                int x = cx0(i), z = cz0(j);
                int v = r.nextInt(100);
                if (v < 14) {
                    for (int a = 0; a < 3; a++)
                        for (int c = 0; c < 3; c++) p.set(x + a, 1, z + c, b.SCULK);
                    if (r.nextInt(100) < 35 && air(x + 1, 2, z + 1)) p.set(x + 1, 2, z + 1, b.SENSOR);
                }
                if (r.nextDouble() < lanternDensity && air(x + 1, 6, z + 1)) p.set(x + 1, 6, z + 1, b.LANTERN_H);
                if (r.nextInt(100) < 4 && air(x, 2, z)) p.set(x, 2, z, b.CANDLE);
                if (r.nextInt(100) < 5 && air(x + 2, 6, z + 2)) p.set(x + 2, 6, z + 2, b.COBWEB);
            }
    }

    private void sculkTunnels() {
        for (int t = 0; t < 4; t++) {
            int i = r.nextInt(cw), j = r.nextInt(ch);
            if (hallCell[i][j] || vaultCell[i][j]) continue;
            int prev = -1;
            for (int step = 0; step < 14; step++) {
                int x = cx0(i), z = cz0(j);
                for (int a = 0; a < 3; a++)
                    for (int c = 0; c < 3; c++) {
                        p.set(x + a, 1, z + c, b.SCULK);
                        if (solid(x + a, 7, z + c)) p.set(x + a, 7, z + c, b.SCULK);
                    }
                if (step % 4 == 2) p.set(x + 1, 2, z + 1, b.SHRIEKER);
                else if (step % 2 == 0) p.set(x, 2, z + 2, b.SENSOR);
                if (step == 7) p.zones.add(new CityPlan.ZoneSpot(x, 2, z, "sculk-tunnel"));
                List<Integer> opts = new ArrayList<>();
                for (int d = 0; d < 4; d++) if (isOpen(i, j, d) && prev != (d + 2) % 4) opts.add(d);
                if (opts.isEmpty()) break;
                int d = opts.get(r.nextInt(opts.size()));
                i += DX[d];
                j += DZ[d];
                prev = d;
                if (hallCell[i][j] || vaultCell[i][j]) break;
            }
        }
    }

    // ------------------------------------------------------------------ city level

    private void cityFloor() {
        for (int x = M; x < sx - M; x++)
            for (int z = M; z < sz - M; z++) {
                short id;
                if (x % 8 == 0 || z % 8 == 0) id = r.nextInt(3) == 0 ? b.CRACKED_TILES : b.POLISHED;
                else id = floorMat();
                p.set(x, FLOOR, z, id);
            }
    }

    private void carveRift(int x, int z) {
        for (int y = 2; y < CEIL; y++) p.set(x, y, z, b.AIR);
        int v = r.nextInt(100);
        p.set(x, 1, z, v < 45 ? b.SCULK : (v < 70 ? b.COBBLED : b.DEEPSLATE));
    }

    private void riftSpot(int x, int z) {
        blob(x, z, 3, 1, b.SCULK, false);
        p.set(x, 2, z, b.SHRIEKER);
        p.set(x + 1, 2, z, b.CATALYST);
        p.zones.add(new CityPlan.ZoneSpot(x, 2, z + 2, "rift"));
    }

    private void rifts() {
        rz = (int) (sz * 0.74);
        rx = (int) (sx * 0.80);
        for (int x = M; x < sx - M; x++)
            for (int z = rz - RIFT_HALF; z <= rz + RIFT_HALF; z++) carveRift(x, z);
        for (int z = M; z < sz - M; z++)
            for (int x = rx - RIFT_HALF; x <= rx + RIFT_HALF; x++) carveRift(x, z);
        reserve(0, rz - RIFT_HALF - 3, sx - 1, rz + RIFT_HALF + 3);
        reserve(rx - RIFT_HALF - 3, 0, rx + RIFT_HALF + 3, sz - 1);

        for (int x = M + 14; x < sx - M - 10; x += 26) riftSpot(x, rz + r.nextInt(5) - 2);
        for (int z = M + 14; z < sz - M - 10; z += 26) riftSpot(rx + r.nextInt(5) - 2, z);
        // завалы
        for (int k = 0; k < 45; k++) {
            int x = M + 2 + r.nextInt(sx - 2 * M - 4), z = rz - RIFT_HALF + r.nextInt(2 * RIFT_HALF + 1);
            rubble(x, z);
            int z2 = M + 2 + r.nextInt(sz - 2 * M - 4), x2 = rx - RIFT_HALF + r.nextInt(2 * RIFT_HALF + 1);
            rubble(x2, z2);
        }
        // сундуки на краях разломов
        for (int k = 0; k < 6; k++) {
            String tier = r.nextInt(100) < 30 ? "epic" : "rare";
            for (int t = 0; t < 60; t++) {
                int x = M + 4 + r.nextInt(sx - 2 * M - 8);
                boolean north = r.nextBoolean();
                if (chest(x, 2, north ? rz - RIFT_HALF : rz + RIFT_HALF, north ? 2 : 0, tier, true)) break;
            }
            for (int t = 0; t < 60; t++) {
                int z = M + 4 + r.nextInt(sz - 2 * M - 8);
                boolean west = r.nextBoolean();
                if (chest(west ? rx - RIFT_HALF : rx + RIFT_HALF, 2, z, west ? 1 : 3, tier, true)) break;
            }
        }
    }

    private void rubble(int x, int z) {
        int h = 2 + r.nextInt(7);
        for (int y = 2; y < 2 + h; y++) {
            if (!air(x, y, z)) break;
            p.set(x, y, z, r.nextInt(4) == 0 ? b.DEEPSLATE : b.COBBLED);
        }
    }

    private void shafts() {
        int cx = sx / 2, cz = sz / 2;
        int[][] list = {{cx + 26, cz - 14}, {cx - 42, cz + 16}, {M + 14, cz + 30}, {sx - 60, cz - 48}};
        for (int[] s : list) shaft(s[0], s[1]);
    }

    /** Лестница из города в катакомбы (идёт на восток вниз). */
    private void shaft(int x0, int zc) {
        reserve(x0 - 3, zc - 3, x0 + 14, zc + 3);
        for (int i = 0; i <= 10; i++) {
            int ys = FLOOR - i;
            for (int dz = -1; dz <= 1; dz++) {
                int x = x0 + i, z = zc + dz;
                for (int y = ys + 1; y <= ys + 5; y++) p.set(x, y, z, b.AIR);
                for (int y = 2; y < ys; y++) p.set(x, y, z, b.DEEPSLATE);
                p.set(x, ys, z, b.STAIRS_B[3]); // ступень поднимается на запад
            }
        }
        for (int i = 11; i <= 13; i++)
            for (int dz = -1; dz <= 1; dz++) {
                fill(x0 + i, 2, zc + dz, x0 + i, 6, zc + dz, b.AIR);
                p.set(x0 + i, 1, zc + dz, floorMat());
            }
        for (int i : new int[]{3, 6, 9}) {
            int y = FLOOR - i + 4;
            if (air(x0 + i, y, zc) && solid(x0 + i, y + 1, zc)) p.set(x0 + i, y, zc, b.LANTERN_H);
        }
        for (int sgn = -2; sgn <= 2; sgn += 4) {
            fill(x0 - 1, WALK, zc + sgn, x0 - 1, WALK + 3, zc + sgn, b.POLISHED);
            p.set(x0 - 1, WALK + 4, zc + sgn, b.LANTERN);
        }
    }

    private void bridge(boolean alongZ, int c, int a, int e) {
        for (int m = a; m <= e; m++)
            for (int o = -2; o <= 2; o++) {
                int x = alongZ ? c + o : m;
                int z = alongZ ? m : c + o;
                p.set(x, FLOOR, z, Math.abs(o) == 2 ? b.BRICKS : b.TILES);
                p.set(x, FLOOR - 1, z, b.BRICKS);
                if (Math.abs(o) == 2) {
                    if ((m - a) % 5 == 0) {
                        p.set(x, WALK, z, b.BRICKS);
                        p.set(x, WALK + 1, z, b.LANTERN);
                    } else p.set(x, WALK, z, b.SLAB_B);
                }
            }
        int mid = (a + e) / 2;
        int x = alongZ ? c : mid, z = alongZ ? mid : c;
        fill(x, 2, z, x, FLOOR - 2, z, b.POLISHED);
    }

    private void bridges() {
        double[] f = {0.2, 0.45, 0.88};
        for (double v : f) {
            int bx = (int) (sx * v);
            bridge(true, bx, rz - RIFT_HALF - 1, rz + RIFT_HALF + 1);
            reserve(bx - 4, rz - RIFT_HALF - 14, bx + 4, rz + RIFT_HALF + 14);
            int bz = (int) (sz * v);
            bridge(false, bz, rx - RIFT_HALF - 1, rx + RIFT_HALF + 1);
            reserve(rx - RIFT_HALF - 14, bz - 4, rx + RIFT_HALF + 14, bz + 4);
        }
    }

    private int dirToward(int dx, int dz) {
        if (Math.abs(dx) >= Math.abs(dz)) return dx > 0 ? 3 : 1;
        return dz > 0 ? 0 : 2;
    }

    private void plaza() {
        int cx = sx / 2, cz = sz / 2;
        int pr = Math.max(14, (int) (Math.min(sx, sz) * 0.11));
        plazaR = pr;
        reserve(cx - pr - 3, cz - pr - 3, cx + pr + 3, cz + pr + 3);
        for (int dx = -pr; dx <= pr; dx++)
            for (int dz = -pr; dz <= pr; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > pr) continue;
                short m;
                if (d < 4) m = b.CHISELED;
                else if (d < 7) m = b.POLISHED;
                else if (((int) d) % 5 == 0) m = b.POLISHED;
                else if (d > pr - 2) m = b.BRICKS;
                else m = r.nextInt(100) < 8 ? b.CRACKED_TILES : b.TILES;
                p.set(cx + dx, FLOOR, cz + dz, m);
                if (d >= 7 && d < pr - 1 && (Math.abs(dx) <= 1 || Math.abs(dz) <= 1))
                    p.set(cx + dx, WALK, cz + dz, b.BLUE_CARPET);
            }
        for (int k = 0; k < 8; k++) {
            double ang = r.nextDouble() * Math.PI * 2;
            blob(cx + (int) Math.round(Math.cos(ang) * (pr - 3)), cz + (int) Math.round(Math.sin(ang) * (pr - 3)),
                    3, FLOOR, b.SCULK, true);
        }
        // монумент
        fill(cx - 3, WALK, cz - 3, cx + 3, WALK + 1, cz + 3, b.BRICKS);
        fill(cx - 2, WALK + 2, cz - 2, cx + 2, WALK + 2, cz + 2, b.CHISELED);
        fill(cx - 1, WALK + 3, cz - 1, cx + 1, WALK + 14, cz + 1, b.POLISHED);
        fill(cx, WALK + 15, cz, cx, WALK + 20, cz, b.CHISELED);
        p.set(cx, WALK + 21, cz, b.CATALYST);
        for (int a = -2; a <= 2; a += 4)
            for (int c = -2; c <= 2; c += 4) p.set(cx + a, WALK + 3, cz + c, b.LANTERN);
        // кольцо колонн
        for (int k = 0; k < 8; k++) {
            double ang = k * Math.PI / 4;
            int px = cx + (int) Math.round(Math.cos(ang) * 14), pz = cz + (int) Math.round(Math.sin(ang) * 14);
            boolean broken = r.nextInt(100) < 30;
            int hgt = broken ? 5 + r.nextInt(8) : 15;
            fill(px - 1, WALK, pz - 1, px + 1, WALK + hgt, pz + 1, b.POLISHED);
            fill(px - 1, WALK, pz - 1, px + 1, WALK, pz + 1, b.CHISELED);
            if (!broken) p.set(px, WALK + hgt + 1, pz, b.LANTERN);
        }
        // сундуки на площади
        for (int k = 1; k < 8; k += 2) {
            double ang = k * Math.PI / 4;
            int ox = (int) Math.round(Math.cos(ang) * 17), oz = (int) Math.round(Math.sin(ang) * 17);
            chest(cx + ox, WALK, cz + oz, dirToward(ox, oz), "common", false);
        }
        // торговец
        int mx = cx - 8, mz = cz + 8;
        fill(mx - 2, WALK, mz - 1, mx + 2, WALK, mz - 1, b.POLISHED);
        for (int a = -2; a <= 2; a += 4) fill(mx + a, WALK, mz + 1, mx + a, WALK + 3, mz + 1, b.POLISHED);
        for (int a = -2; a <= 2; a++) for (int c = -1; c <= 1; c++) p.set(mx + a, WALK + 4, mz + 1 + c - 1 + 1, b.BLUE_WOOL);
        p.set(mx, WALK + 3, mz + 1, b.LANTERN_H);
        p.merchants.add(new int[]{mx, WALK, mz + 1});
        p.spawnX = cx;
        p.spawnY = WALK;
        p.spawnZ = cz + 8;
    }

    private void temple() {
        int cx = sx / 2, cz = sz / 2;
        int tw = 44, td = 40, h = 24;
        int tx0 = cx - tw / 2, tx1 = tx0 + tw - 1, tz0 = M + 12, tz1 = tz0 + td - 1;
        int yTop = WALK + h - 1, roof = WALK + h;
        reserve(tx0 - 4, tz0 - 4, tx1 + 4, tz1 + 6);
        reserve(cx - 14, tz1, cx + 14, cz - plazaR);

        for (int x = tx0; x <= tx1; x++)
            for (int z = tz0; z <= tz1; z++) {
                p.set(x, FLOOR, z, ((x + z) & 1) == 0 ? b.TILES : b.POLISHED);
                boolean border = x < tx0 + 2 || x > tx1 - 2 || z < tz0 + 2 || z > tz1 - 2;
                if (border) for (int y = WALK; y <= yTop; y++) p.set(x, y, z, wallMat());
                p.set(x, roof, z, wallMat());
                p.set(x, roof + 1, z, wallMat());
                if (x == tx0 || x == tx1 || z == tz0 || z == tz1) p.set(x, roof + 2, z, b.BRICKS);
            }
        // вход
        fill(cx - 3, WALK, tz1 - 1, cx + 3, WALK + 9, tz1, b.AIR);
        for (int a = -3; a <= 3; a += 6) fill(cx + a, WALK + 8, tz1 - 1, cx + a, WALK + 9, tz1, b.BRICKS);
        // перегородка святилища + секретная стенка
        fill(tx0 + 2, WALK, tz0 + 11, tx1 - 2, yTop, tz0 + 11, b.BRICKS);
        fill(cx - 2, WALK, tz0 + 11, cx + 2, WALK + 4, tz0 + 11, b.CRACKED_BRICKS);
        // святилище
        for (int x = cx - 12; x <= cx + 12; x++)
            for (int z = tz0 + 2; z <= tz0 + 10; z++) if (r.nextInt(100) < 60) p.set(x, FLOOR, z, b.SCULK);
        int[][] shr = {{-8, 4}, {8, 4}, {-8, 8}, {8, 8}};
        for (int[] o : shr) p.set(cx + o[0], WALK, tz0 + o[1], b.SHRIEKER);
        p.set(cx - 6, WALK, tz0 + 6, b.CATALYST);
        p.set(cx + 6, WALK, tz0 + 6, b.CATALYST);
        p.set(cx - 4, WALK, tz0 + 8, b.SENSOR);
        p.set(cx + 4, WALK, tz0 + 8, b.SENSOR);
        p.set(cx, FLOOR, tz0 + 2, b.CHISELED);
        chest(cx, WALK, tz0 + 2, 2, "legendary", false);
        chest(cx - 10, WALK, tz0 + 2, 2, "epic", false);
        chest(cx + 10, WALK, tz0 + 2, 2, "epic", false);
        p.set(cx - 2, WALK, tz0 + 2, b.CANDLE);
        p.set(cx + 2, WALK, tz0 + 2, b.CANDLE);
        p.zones.add(new CityPlan.ZoneSpot(cx, WALK, tz0 + 6, "temple"));
        // алтарь
        fill(cx - 3, WALK, tz0 + 13, cx + 3, WALK, tz0 + 14, b.CHISELED);
        p.set(cx, WALK + 1, tz0 + 13, b.CRYING);
        p.set(cx - 3, WALK + 1, tz0 + 14, b.LANTERN);
        p.set(cx + 3, WALK + 1, tz0 + 14, b.LANTERN);
        chest(cx - 7, WALK, tz0 + 13, 2, "rare", false);
        chest(cx + 7, WALK, tz0 + 13, 2, "rare", false);
        // нефа: ковёр, колонны, фонари, библиотека
        for (int z = tz0 + 15; z <= tz1 - 2; z++)
            for (int x = cx - 1; x <= cx + 1; x++) if (air(x, WALK, z)) p.set(x, WALK, z, b.BLUE_CARPET);
        for (int z = tz0 + 16; z <= tz1 - 4; z += 6)
            for (int sg = -1; sg <= 1; sg += 2) {
                int px = cx + sg * 8;
                fill(px, WALK, z, px, yTop, z, b.POLISHED);
                p.set(px, WALK, z, b.CHISELED);
                p.set(px, yTop, z, b.CHISELED);
                p.set(cx + sg * 4, yTop, z, b.LANTERN_H);
                p.set(cx + sg * 12, yTop, z, b.LANTERN_H);
            }
        for (int z = tz0 + 16; z <= tz1 - 4; z += 3) {
            fill(tx0 + 2, WALK, z, tx0 + 3, WALK + 3, z, b.BOOKSHELF);
            fill(tx1 - 3, WALK, z, tx1 - 2, WALK + 3, z, b.BOOKSHELF);
        }
        chest(tx0 + 4, WALK, tz1 - 6, 1, "epic", false);
        chest(tx1 - 4, WALK, tz1 - 6, 3, "epic", false);
        chest(tx0 + 4, WALK, tz0 + 22, 1, "rare", false);
        chest(tx1 - 4, WALK, tz0 + 22, 3, "rare", false);
        // окна
        for (int z = tz0 + 6; z <= tz1 - 4; z += 6) {
            fill(tx0, WALK + 6, z, tx0 + 1, WALK + 10, z + 1, b.AIR);
            fill(tx1 - 1, WALK + 6, z, tx1, WALK + 10, z + 1, b.AIR);
        }
        // фасад и аллея
        for (int px : new int[]{cx - 14, cx - 8, cx + 8, cx + 14}) {
            fill(px - 1, WALK, tz1 + 1, px + 1, yTop, tz1 + 3, b.POLISHED);
            p.set(px, yTop + 1, tz1 + 2, b.LANTERN);
        }
        for (int z = tz1 + 6; z < cz - plazaR - 2; z += 8)
            for (int sg = -1; sg <= 1; sg += 2) {
                int px = cx + sg * 7;
                fill(px, WALK, z, px, WALK + 11, z, b.POLISHED);
                p.set(px, WALK + 12, z, b.LANTERN);
            }
        for (int z = tz1 + 1; z < cz - plazaR; z++)
            for (int x = cx - 2; x <= cx + 2; x++) if (air(x, WALK, z)) p.set(x, WALK, z, b.BLUE_CARPET);
    }

    private void colossalColumns() {
        int made = 0;
        for (int t = 0; t < 200 && made < 26; t++) {
            int x = M + 6 + r.nextInt(sx - 2 * M - 12), z = M + 6 + r.nextInt(sz - 2 * M - 12);
            if (!free(x - 4, z - 4, x + 4, z + 4)) continue;
            reserve(x - 5, z - 5, x + 5, z + 5);
            fill(x - 1, WALK, z - 1, x + 1, CEIL - 1, z + 1, b.BRICKS);
            for (int y = WALK; y < CEIL; y += 8) fill(x - 2, y, z - 2, x + 2, y + 1, z + 2, b.CHISELED);
            fill(x - 2, WALK, z - 2, x + 2, WALK + 1, z + 2, b.POLISHED);
            made++;
        }
    }

    private void buildings() {
        int target = cfgBuildings > 0 ? cfgBuildings : (sx * sz) / 700;
        int made = 0;
        for (int t = 0; t < target * 14 && made < target; t++) {
            int w = 7 + r.nextInt(9), d = 7 + r.nextInt(9);
            int x0 = M + 5 + r.nextInt(Math.max(1, sx - 2 * M - 10 - w));
            int z0 = M + 5 + r.nextInt(Math.max(1, sz - 2 * M - 10 - d));
            if (!free(x0 - 3, z0 - 3, x0 + w + 2, z0 + d + 2)) continue;
            reserve(x0 - 2, z0 - 2, x0 + w + 1, z0 + d + 1);
            building(x0, z0, w, d, r.nextInt(100) < 35 ? 2 : 1);
            made++;
        }
    }

    private void building(int x0, int z0, int w, int d, int floors) {
        int yb = WALK, ht = floors == 2 ? 12 : 6, top = yb + ht - 1;
        int x1 = x0 + w - 1, z1 = z0 + d - 1;
        for (int x = x0; x <= x1; x++)
            for (int z = z0; z <= z1; z++) {
                boolean border = x == x0 || x == x1 || z == z0 || z == z1;
                p.set(x, FLOOR, z, floorMat());
                if (border) for (int y = yb; y <= top; y++) if (r.nextInt(100) >= 3) p.set(x, y, z, wallMat());
                if (r.nextInt(100) >= 4) p.set(x, top + 1, z, wallMat());
            }
        int cxd = (x0 + x1) / 2, czd = (z0 + z1) / 2;
        int side = r.nextInt(4);
        if (side == 0) fill(cxd - 1, yb, z0, cxd + 1, yb + 3, z0, b.AIR);
        else if (side == 1) fill(x1, yb, czd - 1, x1, yb + 3, czd + 1, b.AIR);
        else if (side == 2) fill(cxd - 1, yb, z1, cxd + 1, yb + 3, z1, b.AIR);
        else fill(x0, yb, czd - 1, x0, yb + 3, czd + 1, b.AIR);
        for (int z = z0 + 2; z <= z1 - 2; z += 4) {
            fill(x0, yb + 2, z, x0, yb + 3, z, b.AIR);
            fill(x1, yb + 2, z, x1, yb + 3, z, b.AIR);
        }
        for (int x = x0 + 2; x <= x1 - 2; x += 4) {
            fill(x, yb + 2, z0, x, yb + 3, z0, b.AIR);
            fill(x, yb + 2, z1, x, yb + 3, z1, b.AIR);
        }
        if (floors == 2) {
            fill(x0 + 1, yb + 6, z0 + 1, x1 - 1, yb + 6, z1 - 1, b.TILES);
            boolean west = side != 3;
            int lx = west ? x0 + 1 : x1 - 1;
            int ld = west ? 1 : 3;
            for (int y = yb; y <= yb + 7; y++) p.set(lx, y, czd, b.LADDER[ld]);
        }
        String tier = floors == 2 ? (r.nextInt(100) < 40 ? "epic" : "rare")
                : (w * d > 130 ? (r.nextBoolean() ? "rare" : "common") : "common");
        chestInside(x0, z0, w, d, yb, floors == 2 ? "rare" : tier);
        if (floors == 2) chestInside(x0, z0, w, d, yb + 7, tier);
        if (air(x0 + 1, yb, z0 + 1) && r.nextBoolean()) p.set(x0 + 1, yb, z0 + 1, b.CANDLE);
        if (air(x1 - 1, yb, z1 - 1) && r.nextBoolean()) p.set(x1 - 1, yb, z1 - 1, b.CANDLE);
        if (r.nextInt(100) < 40) fill(cxd - 1, yb, czd - 1, cxd + 1, yb, czd + 1, b.BLUE_CARPET);
        int ly = floors == 2 ? yb + 5 : top;
        if (air(cxd, ly, czd + 1) && solid(cxd, ly + 1, czd + 1)) p.set(cxd, ly, czd + 1, b.LANTERN_H);
        // руины
        int n = 1 + r.nextInt(2);
        for (int k = 0; k < n; k++) {
            int ex = x0 + r.nextInt(w), ez = z0 + r.nextInt(d), rw = 2 + r.nextInt(4);
            fill(ex - rw / 2, yb + 2 + r.nextInt(3), ez - rw / 2, ex + rw / 2, top + 1, ez + rw / 2, b.AIR);
        }
        for (int k = 0; k < 6; k++) {
            int x = x0 - 2 + r.nextInt(w + 4), z = z0 - 2 + r.nextInt(d + 4);
            if ((x < x0 || x > x1 || z < z0 || z > z1) && air(x, WALK, z) && solid(x, FLOOR, z))
                p.set(x, WALK, z, b.COBBLED);
        }
    }

    private void chestInside(int x0, int z0, int w, int d, int y, String tier) {
        int x1 = x0 + w - 1, z1 = z0 + d - 1;
        for (int t = 0; t < 50; t++) {
            int side = r.nextInt(4);
            int x, z, dir;
            if (side == 0) { z = z0 + 1; x = x0 + 2 + r.nextInt(Math.max(1, w - 4)); dir = 2; }
            else if (side == 1) { x = x1 - 1; z = z0 + 2 + r.nextInt(Math.max(1, d - 4)); dir = 3; }
            else if (side == 2) { z = z1 - 1; x = x0 + 2 + r.nextInt(Math.max(1, w - 4)); dir = 0; }
            else { x = x0 + 1; z = z0 + 2 + r.nextInt(Math.max(1, d - 4)); dir = 1; }
            if (chest(x, y, z, dir, tier, true)) return;
        }
    }

    private void streets() {
        for (int x = M + 6; x < sx - M - 6; x += 11)
            for (int z = M + 6; z < sz - M - 6; z += 11) {
                int px = x + r.nextInt(5) - 2, pz = z + r.nextInt(5) - 2;
                if (px < 0 || pz < 0 || px >= sx || pz >= sz) continue;
                if (r.nextInt(100) >= 55 || occ[px][pz]) continue;
                if (!solid(px, FLOOR, pz) || solid(px, WALK, pz)) continue;
                fill(px, WALK, pz, px, WALK + 2, pz, b.POLISHED);
                p.set(px, WALK + 3, pz, b.LANTERN);
            }
        for (int k = 0; k < 90; k++) {
            int x = M + 4 + r.nextInt(sx - 2 * M - 8), z = M + 4 + r.nextInt(sz - 2 * M - 8);
            if (occ[x][z] || !solid(x, FLOOR, z) || solid(x, WALK, z)) continue;
            int hgt = 2 + r.nextInt(6);
            short m = wallMat();
            for (int y = WALK; y < WALK + hgt; y++) p.set(x, y, z, m);
        }
        for (int k = 0; k < 14; k++) {
            int x = M + 8 + r.nextInt(sx - 2 * M - 16), z = M + 8 + r.nextInt(sz - 2 * M - 16);
            if (occ[x][z] || !solid(x, FLOOR, z) || solid(x, WALK, z)) continue;
            int rad = 3 + r.nextInt(3);
            for (int dx = -rad; dx <= rad; dx++)
                for (int dz = -rad; dz <= rad; dz++) {
                    int px = x + dx, pz = z + dz;
                    if (dx * dx + dz * dz > rad * rad || px < 0 || pz < 0 || px >= sx || pz >= sz) continue;
                    if (occ[px][pz] || !solid(px, FLOOR, pz) || solid(px, WALK, pz)) continue;
                    p.set(px, FLOOR, pz, b.SCULK);
                    if (r.nextInt(100) < 5) p.set(px, WALK, pz, b.SENSOR);
                }
            if (r.nextInt(100) < 70) p.set(x, WALK, z, b.SHRIEKER);
            p.set(x + 1, WALK, z + 1, b.CATALYST);
            p.zones.add(new CityPlan.ZoneSpot(x + 2, WALK, z, "street"));
        }
    }

    private void ceilingDecor() {
        for (int k = 0; k < 150; k++)
            blob(M + 3 + r.nextInt(sx - 2 * M - 6), M + 3 + r.nextInt(sz - 2 * M - 6), 3 + r.nextInt(5), CEIL, b.SCULK, true);
        for (int k = 0; k < 550; k++) {
            int x = M + 1 + r.nextInt(sx - 2 * M - 2), z = M + 1 + r.nextInt(sz - 2 * M - 2);
            if (!air(x, CEIL - 1, z)) continue;
            int len = 2 + r.nextInt(7);
            for (int j = 0; j < len; j++) {
                int y = CEIL - 1 - j;
                if (!air(x, y, z)) break;
                p.set(x, y, z, r.nextInt(5) == 0 ? b.TUFF : b.COBBLED);
            }
        }
    }

    private void finish() {
        // убираем сундуки, разрушенные руинами
        List<CityPlan.ChestSpot> ok = new ArrayList<>();
        for (CityPlan.ChestSpot c : p.chests) {
            short id = p.get(c.x, c.y, c.z);
            for (int d = 0; d < 4; d++)
                if (id == b.CHEST[d]) {
                    ok.add(c);
                    break;
                }
        }
        p.chests.clear();
        p.chests.addAll(ok);
    }
}
