package com.wardencity;

/** Палитра блоков (создаётся в основном потоке). Направления: 0=N 1=E 2=S 3=W */
final class Blocks {
    static final String[] DIR = {"north", "east", "south", "west"};

    final short AIR = 0;
    final short DEEPSLATE, COBBLED, BRICKS, CRACKED_BRICKS, TILES, CRACKED_TILES, POLISHED, CHISELED,
            REINFORCED, TUFF, SCULK, CATALYST, SHRIEKER, SENSOR, BLUE_WOOL, BLUE_CARPET,
            LANTERN_H, LANTERN, CANDLE, COBWEB, SOUL_SOIL, BOOKSHELF, CRYING, SLAB_B, SLAB_T;
    final short[] CHEST = new short[4];
    final short[] LADDER = new short[4];
    final short[] STAIRS_B = new short[4];

    Blocks(CityPlan p) {
        DEEPSLATE = p.reg("minecraft:deepslate");
        COBBLED = p.reg("minecraft:cobbled_deepslate");
        BRICKS = p.reg("minecraft:deepslate_bricks");
        CRACKED_BRICKS = p.reg("minecraft:cracked_deepslate_bricks");
        TILES = p.reg("minecraft:deepslate_tiles");
        CRACKED_TILES = p.reg("minecraft:cracked_deepslate_tiles");
        POLISHED = p.reg("minecraft:polished_deepslate");
        CHISELED = p.reg("minecraft:chiseled_deepslate");
        REINFORCED = p.reg("minecraft:reinforced_deepslate");
        TUFF = p.reg("minecraft:tuff");
        SCULK = p.reg("minecraft:sculk");
        CATALYST = p.reg("minecraft:sculk_catalyst");
        SHRIEKER = p.reg("minecraft:sculk_shrieker[can_summon=true]");
        SENSOR = p.reg("minecraft:sculk_sensor");
        BLUE_WOOL = p.reg("minecraft:blue_wool");
        BLUE_CARPET = p.reg("minecraft:blue_carpet");
        LANTERN_H = p.reg("minecraft:soul_lantern[hanging=true]");
        LANTERN = p.reg("minecraft:soul_lantern[hanging=false]");
        CANDLE = p.reg("minecraft:candle[candles=3,lit=true]");
        COBWEB = p.reg("minecraft:cobweb");
        SOUL_SOIL = p.reg("minecraft:soul_soil");
        BOOKSHELF = p.reg("minecraft:bookshelf");
        CRYING = p.reg("minecraft:crying_obsidian");
        SLAB_B = p.reg("minecraft:deepslate_brick_slab[type=bottom]");
        SLAB_T = p.reg("minecraft:deepslate_brick_slab[type=top]");
        for (int d = 0; d < 4; d++) {
            CHEST[d] = p.reg("minecraft:chest[facing=" + DIR[d] + ",type=single]");
            LADDER[d] = p.reg("minecraft:ladder[facing=" + DIR[d] + "]");
            STAIRS_B[d] = p.reg("minecraft:deepslate_brick_stairs[facing=" + DIR[d] + ",half=bottom]");
        }
    }
}
