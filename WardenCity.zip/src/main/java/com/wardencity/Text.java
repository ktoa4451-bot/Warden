package com.wardencity;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

public final class Text {
    private static final LegacyComponentSerializer S = LegacyComponentSerializer.legacyAmpersand();

    private Text() {}

    public static Component c(String s) {
        return S.deserialize(s == null ? "" : s);
    }

    public static Component item(String s) {
        return c(s).decoration(TextDecoration.ITALIC, false);
    }
}
