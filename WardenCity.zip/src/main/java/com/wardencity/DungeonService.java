package com.wardencity;

import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Level;

/** Создание / удаление / восстановление данжа (всё порциями по тикам, без лагов). */
public final class DungeonService {
    private final WardenCityPlugin plugin;
    private boolean busy;

    public DungeonService(WardenCityPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean isBusy() {
        return busy;
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    // ------------------------------------------------------------ create

    public void create(CommandSender who, Long seedArg) {
        if (busy) {
            plugin.send(who, "&cУже идёт операция, подождите.");
            return;
        }
        if (plugin.data().dungeon != null) {
            plugin.send(who, "&cДанж уже создан. Используйте &e/wardencity reset confirm&c или &e/wardencity delete confirm&c.");
            return;
        }
        World w = plugin.ensureWorld();
        if (w == null) {
            plugin.send(who, "&cМир не найден и не создан. Проверьте world.name и world.create-if-missing.");
            return;
        }
        FileConfiguration c = plugin.getConfig();
        Dungeon d = new Dungeon();
        d.world = w.getName();
        d.ox = c.getInt("dungeon.origin.x", 0);
        d.oy = c.getInt("dungeon.origin.y", 0);
        d.oz = c.getInt("dungeon.origin.z", 0);
        d.sx = clamp(c.getInt("dungeon.size-x", 192), 160, 512);
        d.sz = clamp(c.getInt("dungeon.size-z", 192), 160, 512);
        d.sy = clamp(c.getInt("dungeon.height", 48), 44, 120);
        long cfgSeed = c.getLong("generation.seed", 0);
        d.seed = seedArg != null ? seedArg : (cfgSeed != 0 ? cfgSeed : new Random().nextLong());
        if (d.oy < w.getMinHeight() || d.oy + d.sy > w.getMaxHeight()) {
            plugin.send(who, "&cДанж не помещается по высоте мира (" + w.getMinHeight() + ".." + w.getMaxHeight()
                    + "). Измените dungeon.origin.y / dungeon.height.");
            return;
        }
        busy = true;
        build(who, d);
    }

    private void build(CommandSender who, Dungeon d) {
        World w = Bukkit.getWorld(d.world);
        if (w == null) {
            busy = false;
            plugin.send(who, "&cМир " + d.world + " не загружен.");
            return;
        }
        FileConfiguration c = plugin.getConfig();
        plugin.send(who, "&7Генерация плана данжа (сид &e" + d.seed + "&7, " + d.sx + "x" + d.sz + "x" + d.sy + ")...");
        final CityPlan plan = new CityPlan(d.sx, d.sy, d.sz);
        final Blocks blocks = new Blocks(plan);
        final int halls = c.getInt("generation.halls", 0);
        final int vaults = c.getInt("generation.vaults", 8);
        final int buildings = c.getInt("generation.buildings", 0);
        final double density = c.getDouble("generation.chest-density", 0.7);
        final double lanterns = c.getDouble("generation.lantern-density", 0.25);
        final int budget = Math.max(1000, c.getInt("generation.blocks-per-tick", 12000));

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                new CityGenerator(plan, blocks, d.seed, halls, vaults, buildings, density, lanterns).generate();
            } catch (Throwable t) {
                plugin.getLogger().log(Level.SEVERE, "Ошибка генерации данжа", t);
                Bukkit.getScheduler().runTask(plugin, () -> {
                    busy = false;
                    plugin.send(who, "&cОшибка генерации, подробности в консоли.");
                });
                return;
            }
            Bukkit.getScheduler().runTask(plugin, () -> {
                plugin.send(who, "&7План готов (" + plan.chests.size() + " сундуков). Строю в мире...");
                new RegionTask(plugin, w, d, plan, budget, who,
                        () -> finishCreate(who, w, d, plan),
                        () -> {
                            busy = false;
                            plugin.send(who, "&cОшибка при постройке, подробности в консоли.");
                        }).runTaskTimer(plugin, 1L, 1L);
            });
        });
    }

    private void finishCreate(CommandSender who, World w, Dungeon d, CityPlan plan) {
        ChestManager cm = plugin.chests();
        cm.clearAll();
        for (CityPlan.ChestSpot cs : plan.chests) cm.register(d.ox + cs.x, d.oy + cs.y, d.oz + cs.z, cs.tier);
        d.merchants.clear();
        for (int[] m : plan.merchants) d.merchants.add(new double[]{d.ox + m[0] + 0.5, d.oy + m[1], d.oz + m[2] + 0.5});
        d.zones.clear();
        for (CityPlan.ZoneSpot z : plan.zones)
            d.zones.add(new Dungeon.Zone(d.ox + z.x + 0.5, d.oy + z.y, d.oz + z.z + 0.5, z.kind));
        d.spawnX = d.ox + plan.spawnX + 0.5;
        d.spawnY = d.oy + plan.spawnY;
        d.spawnZ = d.oz + plan.spawnZ + 0.5;
        plugin.data().dungeon = d;
        w.setSpawnLocation((int) d.spawnX, (int) d.spawnY, (int) d.spawnZ);
        plugin.merchant().spawnAll(w, d);
        plugin.data().save(true);
        busy = false;
        plugin.send(who, "&aДанж «Город Вардена» готов! Сундуков: &e" + cm.count() + "&a, зон Вардена: &e"
                + d.zones.size() + "&a. Телепорт: &e/wardencity teleport");
        plugin.getLogger().info("Данж создан: сундуков " + cm.count() + ", зон " + d.zones.size());
    }

    // ------------------------------------------------------------ delete / reset

    public void delete(CommandSender who) {
        if (busy) {
            plugin.send(who, "&cУже идёт операция, подождите.");
            return;
        }
        Dungeon d = plugin.data().dungeon;
        if (d == null) {
            plugin.send(who, "&cДанж не создан.");
            return;
        }
        busy = true;
        startClear(who, d, () -> {
            plugin.chests().clearAll();
            plugin.data().dungeon = null;
            plugin.data().save(true);
            busy = false;
            plugin.send(who, "&aДанж удалён.");
        });
    }

    public void reset(CommandSender who) {
        if (busy) {
            plugin.send(who, "&cУже идёт операция, подождите.");
            return;
        }
        Dungeon d = plugin.data().dungeon;
        if (d == null) {
            plugin.send(who, "&cДанж не создан. Используйте /wardencity create.");
            return;
        }
        busy = true;
        startClear(who, d, () -> {
            plugin.chests().clearAll();
            plugin.data().dungeon = null;
            build(who, d); // тот же сид, размеры и позиция
        });
    }

    private void startClear(CommandSender who, Dungeon d, Runnable done) {
        World w = Bukkit.getWorld(d.world);
        if (w == null) {
            busy = false;
            plugin.send(who, "&cМир " + d.world + " не загружен.");
            return;
        }
        Location exit = plugin.exitLocation();
        for (Player p : w.getPlayers())
            if (d.contains(w, p.getLocation().getX(), p.getLocation().getY(), p.getLocation().getZ())) {
                p.teleport(exit);
                plugin.send(p, "&eДанж перестраивается, вы перемещены наружу.");
            }
        plugin.merchant().removeAll(w, d);
        plugin.send(who, "&7Очистка области данжа...");
        int budget = Math.max(1000, plugin.getConfig().getInt("generation.blocks-per-tick", 12000));
        new RegionTask(plugin, w, d, null, budget, who, () -> {
            for (Entity e : new ArrayList<>(w.getEntities()))
                if (!(e instanceof Player) && d.contains(w, e.getLocation().getX(), e.getLocation().getY(), e.getLocation().getZ()))
                    e.remove();
            done.run();
        }, () -> {
            busy = false;
            plugin.send(who, "&cОшибка при очистке, подробности в консоли.");
        }).runTaskTimer(plugin, 1L, 1L);
    }

    // ------------------------------------------------------------ задача по чанкам

    private static final class RegionTask extends BukkitRunnable {
        private final WardenCityPlugin plugin;
        private final World w;
        private final Dungeon d;
        private final CityPlan plan; // null = очистка
        private final int budget;
        private final CommandSender who;
        private final Runnable done, fail;
        private final int minCx, maxCx, minCz, maxCz;
        private int cx, cz;
        private long doneChunks;
        private final long totalChunks;
        private int lastStep = 0;

        RegionTask(WardenCityPlugin plugin, World w, Dungeon d, CityPlan plan, int budget, CommandSender who,
                   Runnable done, Runnable fail) {
            this.plugin = plugin;
            this.w = w;
            this.d = d;
            this.plan = plan;
            this.budget = budget;
            this.who = who;
            this.done = done;
            this.fail = fail;
            this.minCx = d.ox >> 4;
            this.maxCx = (d.ox + d.sx - 1) >> 4;
            this.minCz = d.oz >> 4;
            this.maxCz = (d.oz + d.sz - 1) >> 4;
            this.cx = minCx;
            this.cz = minCz;
            this.totalChunks = (long) (maxCx - minCx + 1) * (maxCz - minCz + 1);
        }

        @Override
        public void run() {
            try {
                int used = 0;
                while (cx <= maxCx && used < budget) {
                    used += plan != null ? paste(cx, cz) : clear(cx, cz);
                    doneChunks++;
                    cz++;
                    if (cz > maxCz) {
                        cz = minCz;
                        cx++;
                    }
                }
                int step = (int) (doneChunks * 4 / totalChunks);
                if (step > lastStep && cx <= maxCx) {
                    lastStep = step;
                    plugin.send(who, "&7" + (plan != null ? "Постройка" : "Очистка") + ": &e" + (step * 25) + "%");
                }
                if (cx > maxCx) {
                    cancel();
                    done.run();
                }
            } catch (Throwable t) {
                cancel();
                plugin.getLogger().log(Level.SEVERE, "Ошибка в задаче данжа", t);
                fail.run();
            }
        }

        private int paste(int ccx, int ccz) {
            Chunk ch = w.getChunkAt(ccx, ccz);
            int bx0 = ccx << 4, bz0 = ccz << 4;
            int placed = 0;
            int minH = w.getMinHeight(), maxH = w.getMaxHeight();
            for (int lx = 0; lx < 16; lx++) {
                int rx = bx0 + lx - d.ox;
                if (rx < 0 || rx >= d.sx) continue;
                for (int lz = 0; lz < 16; lz++) {
                    int rz = bz0 + lz - d.oz;
                    if (rz < 0 || rz >= d.sz) continue;
                    for (int ry = 0; ry < d.sy; ry++) {
                        short id = plan.get(rx, ry, rz);
                        if (id == 0) continue;
                        int wy = d.oy + ry;
                        if (wy < minH || wy >= maxH) continue;
                        ch.getBlock(lx, wy, lz).setBlockData(plan.blockData(id), false);
                        placed++;
                    }
                }
            }
            return placed;
        }

        private int clear(int ccx, int ccz) {
            Chunk ch = w.getChunkAt(ccx, ccz);
            int bx0 = ccx << 4, bz0 = ccz << 4;
            int cost = 0, scanned = 0;
            int minH = w.getMinHeight(), maxH = w.getMaxHeight();
            for (int lx = 0; lx < 16; lx++) {
                int rx = bx0 + lx - d.ox;
                if (rx < 0 || rx >= d.sx) continue;
                for (int lz = 0; lz < 16; lz++) {
                    int rz = bz0 + lz - d.oz;
                    if (rz < 0 || rz >= d.sz) continue;
                    for (int ry = 0; ry < d.sy; ry++) {
                        int wy = d.oy + ry;
                        if (wy < minH || wy >= maxH) continue;
                        scanned++;
                        org.bukkit.block.Block b = ch.getBlock(lx, wy, lz);
                        if (b.getType() != Material.AIR) {
                            b.setType(Material.AIR, false);
                            cost++;
                        }
                    }
                }
            }
            return cost + scanned / 8;
        }
    }
}
